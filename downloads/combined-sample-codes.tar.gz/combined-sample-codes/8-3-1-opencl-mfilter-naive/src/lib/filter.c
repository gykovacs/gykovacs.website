#include <filter.h>
#include <math.h>
#include <stdio.h>
#include <float.h>
#include <malloc.h>
#include <stopper.h>
#include <omp.h>
#include <CL/opencl.h>
#include <error.h>
#include <kernelio.h>

#define MAX(a,b) (a>b?a:b)
#define N 3
#define THRESHOLD 0.000001
#define MAX_PLATFORMS 10
#define MAX_DEVICES 10

filter* createGF(float sigma, float theta, float lambda, float psi, float gamma, int stride)
{
  float xtmp, ytmp, xtheta, ytheta, weight;
  int i, j, n, xmax, ymax;
  float sigmax= sigma, sigmay= sigma/gamma;
  filter* f;
  
  xtmp= MAX(fabs(N*sigmax*cos(theta)), fabs(N*sigmay*sin(theta)));
  xtmp= ceil(MAX(1.0, xtmp));
  ytmp= MAX(fabs(N*sigmax*sin(theta)), fabs(N*sigmay*cos(theta)));
  ytmp= ceil(MAX(1.0, ytmp));
  xmax= xtmp;
  ymax= ytmp;
  
  n= (2*xmax + 1)*(2*ymax + 1);
  f= (filter*)malloc(sizeof(filter));
  f->p= (int*)malloc(sizeof(int)*n);
  f->w= (float*)malloc(sizeof(float)*n);
  f->n= 0;
  
  for ( i= -xmax; i <= xmax; ++i )
    for ( j= -ymax; j <= ymax; ++j )
    {
      xtheta= i*cos(theta) + j*sin(theta);
      ytheta= -i*sin(theta) + j*cos(theta);
      
      weight= 1.0/(2*M_PI*sigmax*sigmay)*
	      exp(-0.5*(xtheta*xtheta/(sigmax*sigmax) +
	      ytheta*ytheta/(sigmay*sigmay)));
      if ( weight < THRESHOLD )
	continue;
      weight*= cos(2*M_PI/lambda*xtheta + psi);
      
      f->p[f->n]= i * stride + j;
      f->w[f->n++]= weight;
    }
    
    f->width= (xmax > ymax) ? 2*xmax + 1 : 2*ymax + 1;
    
    return f;
}

float applyFn(filter* f, image* input, int n)
{
  int i, imn= (input->rows) * (input->columns);
  float sum= 0;
  
  for ( i= 0; i < f->n; ++i )
    if ( n + f->p[i] >= 0 && n + f->p[i] < imn )
      sum+= (input->content[n + f->p[i]])*(f->w[i]);
    else if ( n + f->p[i] < 0 )
      sum+= (input->content[imn + n + f->p[i]])*(f->w[i]);
    else if ( n + f->p[i] >= imn )
      sum+= (input->content[n + f->p[i] - imn])*(f->w[i]);
    
  return sum;
}

void applyF(filter* f, image* input, image* output)
{
  int i, imn= (input->rows) * (input->columns);
  
  for ( i= 0; i < imn; ++i )
    output->content[i]= applyFn(f, input, i);
}

void destroyF(filter* f)
{
  free(f->p); free(f->w); free(f);
}

filterSet* createGFS(float sigma, int ntheta, float lambda, float psi, float gamma, int stride)
{
  float t, dtheta= M_PI/ntheta;
  
  filterSet* fs= (filterSet*)malloc(sizeof(filterSet));
  fs->f= (filter**)malloc(sizeof(filter*)*ntheta);
  fs->n= 0;
  
  for ( t= 0; t < M_PI; t+= dtheta )
    fs->f[fs->n++]= createGF(sigma, t, lambda, psi, gamma, stride);
  
  return fs;
}

float applyFSn(filterSet* fs, image* input, int n)
{
  float value, maxValue= -FLT_MAX;
  int i;
  
  for ( i= 0; i < fs->n; ++i )
  {
    value= applyFn(fs->f[i], input, n);
    if ( value > maxValue )
      maxValue= value;
  }
  return maxValue;
}

int prepareFilters(filterSet* fs, float** weights, short** positions, int** lengths)
{
  int i, j, m;
  int n= 0;
  *lengths= (int*)malloc(sizeof(int)*(fs->n + 1));
  for ( i= 0; i < fs->n; ++i )
    n+= fs->f[i]->n;
  *weights= (float*)malloc(sizeof(float)*n);
  *positions= (short*)malloc(sizeof(short)*n);
  
  m= 0;
  for ( i= 0; i < fs->n; ++i )
  {
    (*lengths)[i]= m;
    for ( j= 0; j < fs->f[i]->n; ++j )
    {
      (*weights)[m]= fs->f[i]->w[j];
      (*positions)[m]= fs->f[i]->p[j];
      ++m;
    }
  }
  (*lengths)[i]= m;
  return n;
}

void applyFS(filterSet* fs, image* input, image* output)
{
  size_t imn= input->rows * input->columns;
  int i;

  cl_int err;
  cl_context context;
  cl_command_queue queue;
  cl_program program;
  cl_kernel kernel;
  cl_kernel kernelF2H;
  cl_kernel kernelH2F;
  
  cl_mem memInput;
  cl_mem memOutput;
  cl_mem memWeights;
  cl_mem memPositions;
  cl_mem memLengths;
  cl_mem memWeightsH;
  cl_event event;
  
  float* weights;
  short* positions;
  int* lengths;
  size_t n;
  char flags[]="-cl-fast-relaxed-math";
  
  cl_platform_id platforms[MAX_PLATFORMS];
  cl_context_properties properties[MAX_PLATFORMS*2]= {0};
  cl_uint numDevices;
  cl_device_id devices[MAX_DEVICES];
  cl_uint numPlatforms;
  size_t size;
  
  char* kernelSource;
  size_t kernelLength;
  
  err= clGetPlatformIDs(MAX_PLATFORMS, platforms, &numPlatforms);
  ERROR(err, "clGetPlatformIDs");
  
  for ( i= 0; i < numPlatforms; ++i )
  {
    properties[i*2]= (cl_context_properties)CL_CONTEXT_PLATFORM;
    properties[i*2 + 1]= (cl_context_properties)(platforms[i]);
  }
  
  context= clCreateContextFromType(properties, CL_DEVICE_TYPE_ALL, NULL, NULL, &err);
  ERROR(err, "clCreateContextFromType");
  
  err= clGetContextInfo(context, CL_CONTEXT_DEVICES, MAX_DEVICES*sizeof(cl_device_id), devices, &size);
  ERROR(err, "clGetContextInfo");
  err= clGetContextInfo(context, CL_CONTEXT_NUM_DEVICES, sizeof(cl_uint), &numDevices, &size);
  ERROR(err, "clGetContextInfo");
  
  queue= clCreateCommandQueue(context, devices[0], 0, &err);
  ERROR(err, "clCreateCommandQueue");
  
  readSourceProgram("kernel.k", &kernelSource, &kernelLength);
  program= clCreateProgramWithSource(context, 1, &kernelSource, NULL, &err);
  ERROR(err, "clCreateProgramWithSource");

  err= clBuildProgram(program, numDevices, devices, flags, NULL, NULL);
  ERROR(err, "clBuildProgram");
  
  kernel= clCreateKernel(program, "applyFSn", &err);
  ERROR(err, "clCreateKernel");
  
  n= prepareFilters(fs, &weights, &positions, &lengths); 

  memInput= clCreateBuffer(context, CL_MEM_READ_ONLY, imn*sizeof(float), NULL, &err);
  ERROR(err, "clCreateBuffer");
  memOutput= clCreateBuffer(context, CL_MEM_WRITE_ONLY, imn*sizeof(float), NULL, &err);
  ERROR(err, "clCreateBuffer");
  memWeights= clCreateBuffer(context, CL_MEM_READ_ONLY, n*sizeof(float), NULL, &err);
  ERROR(err, "clCreateBuffer weights");
  memPositions= clCreateBuffer(context, CL_MEM_READ_ONLY, n*sizeof(short), NULL, &err);
  ERROR(err, "clCreateBuffer positions");
  memLengths= clCreateBuffer(context, CL_MEM_READ_ONLY, (fs->n + 1)*sizeof(int), NULL, &err);
  ERROR(err, "clCreateBuffer lengths");

  err= clEnqueueWriteBuffer(queue, memInput, 1, 0, imn*sizeof(float), input->content, 0, NULL, &event);
  ERROR(err, "clEnqueueWriteBuffer");
  err= clEnqueueWriteBuffer(queue, memWeights, 1, 0, n*sizeof(float), weights, 0, NULL, &event);
  ERROR(err, "clEnqueueWriteBuffer");
  err= clEnqueueWriteBuffer(queue, memPositions, 1, 0, n*sizeof(short), positions, 0, NULL, &event);
  ERROR(err, "clEnqueueWriteBuffer");
  err= clEnqueueWriteBuffer(queue, memLengths, 1, 0, (fs->n + 1)*sizeof(int), lengths, 0, NULL, &event);
  ERROR(err, "clEnqueueWriteBuffer");

  err= clSetKernelArg(kernel, 0, sizeof(memInput), &memInput);
  ERROR(err, "clSetKernelArg");
  err= clSetKernelArg(kernel, 1, sizeof(memOutput), &memOutput);
  ERROR(err, "clSetKernelArg");
  err= clSetKernelArg(kernel, 2, sizeof(memWeightsH), &memWeights);
  ERROR(err, "clSetKernelArg");
  err= clSetKernelArg(kernel, 3, sizeof(memPositions), &memPositions);
  ERROR(err, "clSetKernelArg");
  err= clSetKernelArg(kernel, 4, sizeof(memLengths), &memLengths);
  ERROR(err, "clSetKernelArg");
  err= clSetKernelArg(kernel, 5, sizeof(int), &(fs->n));
  ERROR(err, "clSetKernelArg");
  
  err= clEnqueueNDRangeKernel(queue, kernel, 1, NULL, &imn, 0, 0, NULL, &event);
  ERROR(err, "clEnqueueNDRangeKernel");
  
  err= clFinish(queue);
  ERROR(err, "clFinish");

  err= clEnqueueReadBuffer(queue, memOutput, 1, 0, imn*sizeof(float), output->content, 0, NULL, &event);
  ERROR(err, "clEnqueueReadBuffer");
  
  clReleaseMemObject(memInput);
  clReleaseMemObject(memOutput);
  clReleaseMemObject(memWeights);
  clReleaseMemObject(memPositions);
  clReleaseMemObject(memLengths);
  clReleaseKernel(kernel);
  clReleaseProgram(program);
  clReleaseCommandQueue(queue);
  clReleaseContext(context);
  
  free(weights);
  free(positions);
  free(lengths);
}

void destroyFS(filterSet* fs)
{
  int i;
  for ( i= 0; i < fs->n; ++i )
    destroyF(fs->f[i]);
  
  free(fs->f);
  free(fs);
}
