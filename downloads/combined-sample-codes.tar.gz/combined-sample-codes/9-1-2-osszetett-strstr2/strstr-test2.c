#include <stdio.h>
#include <string.h>

int position= 0;

char* strstr2(char* a, char* b)
{
  char* tmp= strstr(a + position, b);
  if ( tmp == NULL )
    position= 0;
  else
    position= (tmp - a) + strlen(b);
  return tmp;
}

int main(int argc, char** argv)
{
  char* p;
  while ( p= strstr2(argv[1], argv[2]) )
  {
    printf("%s\n", p);
    fflush(stdout);
  }

  return 0;
}
