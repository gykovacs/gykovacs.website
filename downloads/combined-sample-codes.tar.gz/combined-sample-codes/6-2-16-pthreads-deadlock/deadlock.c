#include <pthread.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

pthread_mutex_t mutexA;
pthread_mutex_t mutexB;

void* szalA(void* p)
{
    printf("Az A szal megprobalja zarni az A mutexet.\n");
    pthread_mutex_lock(&mutexA);
    printf("Az A szal zarta az A mutexet.\n");
    printf("Az A szal megprobalja zarni a B mutexet.\n");
    pthread_mutex_lock(&mutexB);
    printf("Az A szal zarta a B mutexet.\n");
    printf("Az A szal nyitja a zart mutexeket.\n");
    pthread_mutex_unlock(&mutexB);
    pthread_mutex_unlock(&mutexA);
    pthread_exit(NULL);
}

void* szalB(void* p)
{
    printf("A B szal megprobalja zarni a B mutexet.\n");
    pthread_mutex_lock(&mutexB);
    printf("A B szal zarta a B mutexet.\n");
    printf("A B szal megprobalja zarni az A mutexet.\n");
    pthread_mutex_lock(&mutexA);
    printf("A B szal zarta az A mutexet.\n");
    printf("A B szal nyitja a zart mutexeket.\n");
    pthread_mutex_unlock(&mutexA);
    pthread_mutex_unlock(&mutexB);
    pthread_exit(NULL);
}

int main(int argc, char** argv)
{
    int i;
    pthread_t idA, idB;

    pthread_mutex_init(&mutexA, NULL);
    pthread_mutex_init(&mutexB, NULL);

    pthread_create(&idA, NULL, szalA, NULL);
    pthread_create(&idB, NULL, szalB, NULL);
    
    pthread_join(idA, NULL);
    pthread_join(idB, NULL);

    pthread_mutex_destroy(&mutexA);
    pthread_mutex_destroy(&mutexB);

    return 0;
}
