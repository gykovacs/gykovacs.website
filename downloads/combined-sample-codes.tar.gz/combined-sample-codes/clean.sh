#! /bin/bash

for I in `ls -d */`
do
  if [[ -f ${I}/CMakeLists.txt ]]
  then
    cd ${I}
    make clean
    rm -rf CMakeFiles
    rm -rf bin
    rm -rf lib
    rm CMakeCache.txt
    rm cmake_install.cmake
    rm Makefile
    rm f*.pgm
    rm *.b

    if [[ -f src/app/CMakeLists.txt ]]
    then
        cd src/app
	rm -rf CMakeFiles
	rm CMakeCache.txt
	rm cmake_install.cmake
	rm Makefile
	cd ../..
    fi
    if [[ -f src/lib/CMakeLists.txt ]]
    then
	cd src/lib
	rm -rf CMakeFiles
	rm CMakeCache.txt
	rm cmake_install.cmake
	rm Makefile
	cd ../..
    fi

    cd ..
  else
    cd ${I}
    rm *.b
    cd ..
  fi
done

rm -rf test-results-*
