#include <stdio.h>
#include <stdlib.h>
#include <filter.h>
#include <pgm.h>
#include <image.h>
#include <stopper.h>
#include <mpi.h>

int main(int argc, char** argv)
{
  if ( argc < 6 )
    return printf("Hasznalat: %s <input.pgm> sigma ntheta gamma <output.pgm>\n", argv[0]);
  
  float sigma, gamma;
  int ntheta;
  int rank;
  image* input, *output;
  stopper st;
  
  startS(&st);

  MPI_Init(&argc, &argv);
  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  
  if ( rank == 1 )
  {
    int n, processed= 0;
    MPI_Recv(&n, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
    while ( 1 )
    {
      MPI_Send(NULL, 0, MPI_INT, 0, 0, MPI_COMM_WORLD);
      MPI_Recv(&processed, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
      
      if ( processed == -1 )
	break;
      
      printf("%.2f%%", ((float)processed)/n*100);
      fflush(stdout);
      
      usleep(500000);
      printf("\r");
      fflush(stdout);
    }
    MPI_Finalize();
    return 0;
  }
  
  sigma= atof(argv[2]);
  ntheta= atoi(argv[3]);
  gamma= atof(argv[4]);

  input= readPGMImage(argv[1]);
  output= createI(input->rows, input->columns);
  filterSet* gfs= createGFS(sigma, ntheta, 9, 0, gamma, input->columns);
  
  applyFS(gfs, input, output);
  
  if ( rank == 0 )
    writePGMImage(argv[5], output);
  
  destroyI(input);
  destroyI(output);
  destroyFS(gfs);

  stopS(&st);
  if ( rank == 0 )
  {
    printf("\n");
    tprintf(&st, "\n");
  }
  
  MPI_Finalize();
  
  return 0;
}
