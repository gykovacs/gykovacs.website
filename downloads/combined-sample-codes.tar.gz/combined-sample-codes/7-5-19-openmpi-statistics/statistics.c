#include <stdio.h>
#include <mpi.h>
#include <float.h>
#include <error.h>
#include <math.h>

#define N 10

int main(int argc, char *argv[]) {
  int rank, err, i;
  float numbers[N];
  float statistics[4];
  MPI_Status status;
  MPI_Request requests[6];

  err= MPI_Init(&argc, &argv);
  ERROR(err, "MPI_Init");
 
  err= MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  ERROR(err, "MPI_Comm_rank");
  
  if ( rank == 0 )
  {
    printf("Adjon meg %d szamot!\n", N);
    for ( i= 0; i < N; ++i )
      scanf("%f", numbers + i);
    
    for ( i= 1; i < 4; ++i )
    {
      err= MPI_Isend((void*)numbers, N, MPI_FLOAT, i, 0, MPI_COMM_WORLD, requests + i - 1);
      ERROR(err, "MPI_Send");
      err= MPI_Irecv(statistics + i, 1, MPI_FLOAT, i, 0, MPI_COMM_WORLD, requests + i + 2);
      ERROR(err, "MPI_Recv");
    }
    
    statistics[0]= FLT_MAX;
    for ( i= 0; i < N; ++i )
      if ( numbers[i] < statistics[0] )
	statistics[0]= numbers[i];
    
    err= MPI_Waitall(6, requests, MPI_STATUSES_IGNORE);
    ERROR(err, "MPI_Waitall");
    
    printf("Minimum: %f\nMaximum: %f\nAtlag: %f\nSzoras: %f\n", statistics[0], statistics[1], statistics[2], statistics[3]);
  }
  else if ( rank == 1 )
  {
    err= MPI_Irecv((void*)numbers, N, MPI_FLOAT, 0, 0, MPI_COMM_WORLD, requests);
    ERROR(err, "MPI_Recv");
    err= MPI_Wait(requests, MPI_STATUS_IGNORE);
    ERROR(err, "MPI_Wait");
    
    statistics[0]= -FLT_MAX;
    for ( i= 0; i < N; ++i )
      if ( numbers[i] > statistics[0] )
	statistics[0]= numbers[i];
    
    err= MPI_Isend(statistics, 1, MPI_FLOAT, 0, 0, MPI_COMM_WORLD, requests);
    ERROR(err, "MPI_Send");
  }
  else if ( rank == 2 )
  {
    err= MPI_Irecv((void*)numbers, N, MPI_FLOAT, 0, 0, MPI_COMM_WORLD, requests);
    ERROR(err, "MPI_Recv");
    err= MPI_Wait(requests, MPI_STATUS_IGNORE);
    ERROR(err, "MPI_Wait");
    
    statistics[0]= 0;
    for ( i= 0; i < N; ++i )
      statistics[0]+= numbers[i];
    statistics[0]/= N;
    
    err= MPI_Isend(statistics, 1, MPI_FLOAT, 0, 0, MPI_COMM_WORLD, requests);
    ERROR(err, "MPI_Send");
  }
  else if ( rank == 3 )
  {
    float tmp;
    
    err= MPI_Irecv((void*)numbers, N, MPI_FLOAT, 0, 0, MPI_COMM_WORLD, requests);
    ERROR(err, "MPI_Recv");
    err= MPI_Wait(requests, MPI_STATUS_IGNORE);
    ERROR(err, "MPI_Wait");
    
    statistics[0]= 0;
    tmp= 0;
    for ( i= 0; i < N; ++i )
    {
      statistics[0]+= numbers[i];
      tmp+= numbers[i]*numbers[i];
    }
    tmp/= N;
    statistics[0]/= N;
    statistics[0]= sqrt(tmp - statistics[0]*statistics[0]);
    
    err= MPI_Isend(statistics, 1, MPI_FLOAT, 0, 0, MPI_COMM_WORLD, requests);
    ERROR(err, "MPI_Send");
  }
  
  if ( rank != 0 )
    MPI_Wait(requests, MPI_STATUS_IGNORE);

  err= MPI_Finalize();
  ERROR(err, "MPI_Finalize");
  
  return 0;
}
