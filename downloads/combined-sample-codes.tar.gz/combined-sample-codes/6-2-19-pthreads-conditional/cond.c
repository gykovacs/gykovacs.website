#include <pthread.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

char* leghosszabbArg;
pthread_mutex_t hosszMutex;
pthread_cond_t hosszFeltetel;
int argSzam;
int feldolgozva;

typedef struct parameter
{
    char* sztring;
} parameter;

void* argKiir(void* p)
{
    pthread_mutex_lock(&hosszMutex);
    
    if ( feldolgozva < argSzam )
	pthread_cond_wait(&hosszFeltetel, &hosszMutex);

    printf("A leghosszabb argumentum: %s\n", leghosszabbArg);
    
    pthread_mutex_unlock(&hosszMutex);
    
    pthread_exit(NULL);
}

void* argHosszKiir(void* p)
{
    pthread_mutex_lock(&hosszMutex);
    
    if ( feldolgozva < argSzam)
	pthread_cond_wait(&hosszFeltetel, &hosszMutex);

    printf("A leghosszabb argumentum hossza: %d\n", strlen(leghosszabbArg));
    
    pthread_mutex_unlock(&hosszMutex);
    
    pthread_exit(NULL);
}

void* szal(void* p)
{
    parameter* par= (parameter*)p;
    int ah= strlen(par->sztring);
    int lh= strlen(leghosszabbArg);
    
    pthread_mutex_lock(&hosszMutex);
    
    if ( ah > lh )
	leghosszabbArg= par->sztring;
    if ( ++feldolgozva == argSzam )
	pthread_cond_broadcast(&hosszFeltetel);

    pthread_mutex_unlock(&hosszMutex);
    
    pthread_exit(NULL);
}

int main(int argc, char** argv)
{
    int i;
    pthread_t* ids= (pthread_t*)malloc(sizeof(pthread_t)*(argc + 2));
    parameter* par= (parameter*)malloc(sizeof(parameter)*argc);

    pthread_mutex_init(&hosszMutex, NULL);
    pthread_cond_init(&hosszFeltetel, NULL);
    leghosszabbArg= argv[0];
    argSzam= argc;
    feldolgozva= 0;
    
    for ( i= 0; i < argc; ++i )
    {
	par[i].sztring= argv[i];
	pthread_create(ids + i, NULL, szal, par + i);
    }
    
    pthread_create(ids + argc, NULL, argKiir, NULL);
    pthread_create(ids + argc + 1, NULL, argHosszKiir, NULL);
    
    for ( i= 0; i < argc; ++i )
	pthread_join(ids[i], NULL);
    pthread_join(ids[argc], NULL);
    pthread_join(ids[argc + 1], NULL);

    pthread_mutex_destroy(&hosszMutex);
    pthread_cond_destroy(&hosszFeltetel);

    free(ids);
    free(par);
    
    return 0;
}
