#include <stdio.h>
#include <mpi.h>
#include <error.h>

int main(int argc, char *argv[]) {

  int input= atoi(argv[1]);
  
  int numprocs, rank, err;
  double begin, end;

  err= MPI_Init(&argc, &argv);
  ERROR(err, "MPI_Init");
  
  begin= MPI_Wtime();
  
  err= MPI_Comm_size(MPI_COMM_WORLD, &numprocs);
  ERROR(err, "MPI_Comm_size");
  err= MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  ERROR(err, "MPI_Comm_rank");
  
  end= MPI_Wtime();
  
  if ( rank == 0 )
  {
    char processor_name[MPI_MAX_PROCESSOR_NAME];
    int namelen;
    double ticks;
    
    ticks= MPI_Wtick();
    err= MPI_Get_processor_name(processor_name, &namelen);
    ERROR(err, "MPI_Get_processor_name");
    
    printf("Runtime of potential Master process %d of %d on %s: %fs, time resolution: %fs\n", rank, numprocs, processor_name, end - begin, ticks);
  }
  else
    printf("Runtime of potential Slave process %d of %d: %fs\n", rank, numprocs, end - begin);

  err= MPI_Finalize();
  ERROR(err, "MPI_Finalize");
  
  return 0;
}
