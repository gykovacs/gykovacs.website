#! /bin/bash

cmake -DCMAKE_BUILD_TYPE=release -r .
make
mpirun -np 4 -machinefile hostfile.home ./processornames 4
