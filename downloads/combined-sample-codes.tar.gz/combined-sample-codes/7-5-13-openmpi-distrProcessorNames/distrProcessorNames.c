#include <stdio.h>
#include <mpi.h>
#include <error.h>

int main(int argc, char *argv[]) {
  int rank, err;
  double begin, end;
  char processor_name[MPI_MAX_PROCESSOR_NAME];

  err= MPI_Init(&argc, &argv);
  ERROR(err, "MPI_Init");
 
  err= MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  ERROR(err, "MPI_Comm_rank");
  
  if ( rank == 0 )
  {
    MPI_Status status;
    int numprocs;
    err= MPI_Comm_size(MPI_COMM_WORLD, &numprocs);
    ERROR(err, "MPI_Comm_size");
    int i;
    for ( i= 1; i < numprocs; ++i )
    {
	err= MPI_Recv((void*)processor_name, MPI_MAX_PROCESSOR_NAME, MPI_CHAR, i, 0, MPI_COMM_WORLD, &status);
	ERROR(err, "MPI_Recv");
	printf("Processor name of process %d: %s\n", i, processor_name);
    }
  }
  else
  {
    int namelen;  
    err= MPI_Get_processor_name(processor_name, &namelen);
    ERROR(err, "MPI_Get_processor_name");
    err= MPI_Send((void*)processor_name, namelen, MPI_CHAR, 0, 0, MPI_COMM_WORLD);
    ERROR(err, "MPI_Send");
  }

  err= MPI_Finalize();
  ERROR(err, "MPI_Finalize");
  
  return 0;
}
