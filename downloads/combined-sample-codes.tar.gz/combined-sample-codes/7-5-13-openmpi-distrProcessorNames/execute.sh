#! /bin/bash

cmake -DCMAKE_BUILD_TYPE=release -r .
make
mpirun -machinefile hostfile.home -np 4 distrProcessorNames
