#include <stdio.h>
#include <omp.h>

int main(int argc, char** argv)
{
	int i;
	
	omp_set_num_threads(atoi(argv[1]));
	omp_set_nested(atoi(argv[2]));
	omp_set_max_active_levels(atoi(argv[3]));
	
	printf("fizikai processzorok szama: %d\n", omp_get_num_procs());
	printf("beagyazott parhuzamositas engedelyezve: %d\n", omp_get_nested());
	printf("num_threads kloz nelkul a szalak szama: %d\n", omp_get_max_threads());
	printf("a letrehozhato szalak maximalis szama: %d\n", omp_get_thread_limit());
	printf("a parhuzamosan futo beagyazott regiok szama: %d\n", omp_get_max_active_levels());
	fflush(stdout);
	
	#pragma omp parallel for
	for ( i= 0; i < 2; ++i )
	{
	    printf("parallel - szal: %d/%d\n" \
		    "\tparhuzamos blokkban: %d\n" \
		    "\tszint: %d\n" \
		    "\taktiv szint: %d\n",
		    omp_get_thread_num(), omp_get_num_threads(), omp_in_parallel(),
		    omp_get_level(), omp_get_active_level());
	    fflush(stdout);
	    #pragma omp parallel num_threads(2)
	    {
		    printf("-------- beagyazott parallel - szal: %d/%d\n" \
			    "\t\tparhuzamos blokkban: %d\n" \
			    "\t\tszint: %d\n" \
			    "\t\taktiv szint: %d\n" \
			    "\t\tletrehozo szal: %d/%d\n",
			    omp_get_thread_num(), omp_get_num_threads(), omp_in_parallel(),
			    omp_get_level(), omp_get_active_level(),
			    omp_get_ancestor_thread_num(omp_get_level()-1), 
			    omp_get_team_size(omp_get_level()-1));
		    fflush(stdout);
	    }
	}
	return 0;
}
