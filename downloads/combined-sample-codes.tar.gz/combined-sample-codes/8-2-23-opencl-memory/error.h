#ifndef __ERROR_H__
#define __ERROR_H__

#include <stdio.h>
#include <CL/opencl.h>

#define ERROR(a,b) {if(a != CL_SUCCESS) errorMessage(stdout, a, b);}

void errorMessage(FILE* f, int code, const char* prefix);

#endif __ERROR_H__