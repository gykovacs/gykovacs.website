#ifndef _FILTER_H_
#define _FILTER_H_

#include <image.h>

int threads;

/// szuro tipus
typedef struct filter
{
    float* w;	/// a sulyok tombje
    int* p;	/// a sorfolytonos ertelmezesu poziciok tombje
    int n;	/// a szuro elemeinek szama
    int width;	/// a szuro szelessege
} filter;

/// szurohalmaz tipus
typedef struct filterSet
{
    filter** f;	/// szurok tombje
    int n;	/// szurok szama
    int maxWidth;
} filterSet;

/** Gabor-szuro letrehozasa
 * @param sigma a Gauss-komponens szorasa
 * @param theta a szuro iranya
 * @param lambda hullamhossz
 * @param psi faziseltolas
 * @param gamma keparany
 * @param stride a szurendo kep oszlopainak szama
 * @return a letrehozott szuro objektum 
 */ 
filter* createGF(float sigma, float theta, float lambda, float psi, float gamma, int stride);

/** a parameterkent kapott szuro alkalmazasa az input kep n. pixelere
 * @param f a szuro mutatoja
 * @param input a szurendo kep mutatoja
 * @param n egy pixel indexe sorfolytonos abrazolasban
 * @return az n. pixel szuresenek eredmenye 
 */ 
float applyFn(filter* f, image* input, int n);

/** egy teljes kep szurese
 * @param f a szuro mutatoja
 * @param input a szurendo kep
 * @param output az eredmeny kep 
 */ 
void applyF(filter* f, image* input, image* output);

/** a szuro felszabaditasa
 * @param f a felszabaditando szuro mutatoja 
 */ 
void destroyF(filter* f);

/** Gabor-szuro halmaz letrehozasa
 * @param sigma a Gauss-komponens szorasa
 * @param ntheta szogfelbontas
 * @param lambda hullamhossz
 * @param psi faziseltolas
 * @param gamma keparany
 * @param a kep szurendo oszlopainak szama 
 */
filterSet* createGFS(float sigma, int ntheta, float lambda, float psi, float gamma, int stride);

/** a parameterkent kapott szurohalmaz alkalmazasa az input kep n. pixelere
 * @param fs szurohalmaz mutatoja
 * @param input szurendo kep mutatoja
 * @param n egy pixel indexe sorfolytonos abrazolasban
 * @return az n. pixel szuresenek eredmenye 
 */
float applyFSn(filterSet* fs, image* input, int n);

/** a szurohalmaz alkalmazasa a teljes kepre
 * @param fs szurohalmaz mutatoja
 * @param input a szurendo kep mutatoja
 * @param output az eredmeny kep mutatoja 
 */ 
void applyFS(filterSet* fs, image* input, image* output);

/** a szurohalmaz felszabaditasa
 * @param f a felszabaditando szurohalmaz mutatoja 
 */
void destroyFS(filterSet* f);

#endif
