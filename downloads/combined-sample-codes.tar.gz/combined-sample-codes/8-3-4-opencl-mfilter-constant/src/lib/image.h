#ifndef _IMAGE_H_
#define _IMAGE_H_

#define P(i, r, c) i->content[r * i->columns + c]

/// kepet reprezentalo adatszerkezet
typedef struct image
{
  float* content;	/// a kep tartalma sorfolytonosan
  unsigned rows;		/// a kep sorainak szama
  unsigned columns;	/// a kep oszlopainak szama
} image;

/** rows x columns meretu kep letrehozasa
 * @param rows a kep sorainak szama
 * @param columns a kep oszlopainak szama
 * @return egy uj kep rekord mutatoja
 */ 
image* createI(unsigned rows, unsigned columns);

/** kep felszabaditasa
 * @param i a felszabaditando kep mutatoja
 */ 
void destroyI(image* i);

#endif
