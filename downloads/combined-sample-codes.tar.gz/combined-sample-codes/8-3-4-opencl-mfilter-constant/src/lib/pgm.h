#ifndef _PGM_H_
#define _PGM_H_

#include <stdio.h>
#include <image.h>

/** PGM kep beolvasasa
 * @param filename a beolvasando fajl neve
 * @return a beolvasott kep mutatoja
 */ 
image* readPGMImage(char* filename);

/** kep kiirasa PGM fajlba
 * @param filename a fajl neve
 * @param img a kiirando kep mutatoja
 */ 
void writePGMImage(char* filename, image* img);

#endif