#include <image.h>
#include <malloc.h>

image* createI(unsigned rows, unsigned columns)
{
  image* i= (image*)malloc(sizeof(image));

  i->content= (float*)malloc(sizeof(float)*rows*columns);
  i->rows= rows;
  i->columns= columns;

  return i;
}

void destroyI(image* i)
{
  free(i->content);
  free(i);
}
