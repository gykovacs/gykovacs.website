#include <stdio.h>
#include <mpi.h>
#include <float.h>
#include <error.h>
#include <math.h>

#define N 10

int main(int argc, char *argv[]) {
  int rank, err, i;
  float numbers[N];
  float statistics[4];
  float result;
  
  err= MPI_Init(&argc, &argv);
  ERROR(err, "MPI_Init");
 
  err= MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  ERROR(err, "MPI_Comm_rank");
  
  if ( rank == 0 )
  {
    printf("Adjon meg %d szamot!\n", N);
    for ( i= 0; i < N; ++i )
      scanf("%f", numbers + i);
  }
  
  err= MPI_Bcast((void*)numbers, N, MPI_FLOAT, 0, MPI_COMM_WORLD);
  ERROR(err, "MPI_Send");
    
  if ( rank == 0 )
  {
    result= FLT_MAX;
    for ( i= 0; i < N; ++i )
      if ( numbers[i] < result )
	result= numbers[i];
  }
  else if ( rank == 1 )
  {
    result= -FLT_MAX;
    for ( i= 0; i < N; ++i )
      if ( numbers[i] > result )
	result= numbers[i];
  }
  else if ( rank == 2 )
  {
    result= 0;
    for ( i= 0; i < N; ++i )
      result+= numbers[i];
    result/= N;
  }
  else if ( rank == 3 )
  {
    float tmp= 0;
    result= 0;
    for ( i= 0; i < N; ++i )
    {
      result+= numbers[i];
      tmp+= numbers[i]*numbers[i];
    }
    tmp/= N;
    result/= N;
    result= sqrt(tmp - result*result);
  }
  
  err= MPI_Gather(&result, 1, MPI_FLOAT, statistics, 1, MPI_FLOAT, 0, MPI_COMM_WORLD);

  if ( rank == 0 )
    printf("Minimum: %f\nMaximum: %f\nAtlag: %f\nSzoras: %f\n", statistics[0], statistics[1], statistics[2], statistics[3]);
   

  err= MPI_Finalize();
  ERROR(err, "MPI_Finalize");
  
  return 0;
}
