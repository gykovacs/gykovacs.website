#ifndef _ERROR_H_
#define _ERROR_H_

#include <stdio.h>
#include <errno.h>

#define ERROR(a, b) {if(a) errorMessage(stdout, a, b);}

void errorMessage(FILE* f, int code, char* label);

#endif _ERROR_H_
