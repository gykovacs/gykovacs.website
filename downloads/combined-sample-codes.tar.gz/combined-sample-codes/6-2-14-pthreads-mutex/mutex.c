#include <pthread.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

int maxHossz;
pthread_mutex_t hosszMutex;

typedef struct parameter
{
    char* sztring;
    int id;
    pthread_t* threadID;
} parameter;

void* feldolgoz(void* p)
{
    parameter* par= (parameter*)p;
    int hossz= strlen(par->sztring);
    
    pthread_mutex_lock(&hosszMutex);
    
    printf("Az %d szal zarolta a mutexet (hossz= %d, maxHossz=%d).\n", *(par->threadID), hossz, maxHossz);
    if ( hossz > maxHossz )
	maxHossz= hossz;
    printf("A %d szal nyitja a mutexet (hossz= %d, maxHossz=%d).\n", *(par->threadID), hossz, maxHossz);
    
    pthread_mutex_unlock(&hosszMutex);
    
    pthread_exit(NULL);
}

int main(int argc, char** argv)
{
    int i;
    pthread_t* ids= (pthread_t*)malloc(sizeof(pthread_t)*argc);
    parameter* par= (parameter*)malloc(sizeof(parameter)*argc);

    pthread_mutex_init(&hosszMutex, NULL); 
    maxHossz= -1;
    
    for ( i= 0; i < argc; ++i )
    {
	par[i].sztring= argv[i];
	par[i].id= i;
	par[i].threadID= ids + i;
	pthread_create(ids + i, NULL, szal, par + i);
    }
    for ( i= 0; i < argc; ++i )
	pthread_join(ids[i], NULL);

    pthread_mutex_destroy(&hosszMutex);

    printf("A leghosszabb parancssori argumentum hossza: %d\n", maxHossz);

    free(ids);
    free(par);
    
    return 0;
}
