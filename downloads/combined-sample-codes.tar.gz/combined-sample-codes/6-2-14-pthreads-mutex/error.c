#include <stdio.h>
#include <error.h>

void errorMessage(FILE* f, int code, char* label)
{
  switch(code)
  {
    case EAGAIN: fprintf(f, "%s - Try again.\n", label); break;
    case EINVAL: fprintf(f, "%s - Invalid argument.\n", label); break;
    case EPERM: fprintf(f, "%s - Operation not permitted.\n", label); break;
    case ESRCH: fprintf(f, "%s - No such process.\n", label); break;
    case EDEADLK: fprintf(f, "%s - Resource deadlock would occur.\n", label); break;
    case ENOMEM: fprintf(f, "%s - Out of memory.\n", label); break;
    case EBUSY: fprintf(f, "%s - Device or resource busy.\n", label); break;
    case ETIMEDOUT: fprintf(f, "%s - Connection timed out.\n", label); break;
  }
}