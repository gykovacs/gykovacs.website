#include <stdio.h>

#include <slib.h>
#include <dlib.h>

int main()
{
    printf("Hello world\n");
    printfSL("Hello world\n");
    printfDL("Hello world\n");
    
    return 0;
}
