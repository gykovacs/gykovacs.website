#include <stdio.h>
#include <stdarg.h>
#include <slib.h>

int printfSL(const char* fmt, ...)
{
	va_list args;
	va_start(args, fmt);
	printf("Static library: ");
	return printf(fmt, args);
}
