#ifndef _SLIB_H_
#define _SLIB_H_

int printfSL(const char* fmt, ...);

#endif