#include <stdio.h>
#include <omp.h>

int main(int argc, char** argv)
{
	int i= 0, j= 1, k= 1, l= 3;
	omp_lock_t lock;
	omp_init_lock(&lock);
	
	printf("i: %d j: %d k: %d l: %d\n", i, j, k, l);	
	
	#pragma omp parallel if(atoi(argv[1])), num_threads(4), default(none), shared(i), firstprivate(j), private(k), reduction(*:l), shared(lock)
	{
		omp_set_lock(&lock);
		++i;
		omp_unset_lock(&lock);
		
		printf("Hello world i: %d j: %d k: %d l: %d\n", i, ++j, ++k, ++l);
	}
	
	printf("i: %d j: %d k: %d l: %d\n", i, j, k, l);	
	
	omp_destroy_lock(&lock);
	
	return 0;
}
