#! /bin/bash

./build-apps.sh
./build-kernels.sh
./test-szekv.sh
./test-openmp.sh
./test-pthread.sh
./test-openmpi.sh
./test-opencl.sh
