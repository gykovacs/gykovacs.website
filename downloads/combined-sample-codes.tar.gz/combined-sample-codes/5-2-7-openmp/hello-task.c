#include <stdio.h>
#include <math.h>
#include <omp.h>

int main(int argc, char** argv)
{
    int i;
    
    #pragma omp parallel num_threads(2)
    {
	#pragma omp single
	{
	    for ( i= 0; i < argc; ++i )
	    #pragma omp task shared(argc, argv), firstprivate(i)
	    {
		printf("%s ", argv[i]);
		fflush(stdout);
	    }
	}
    }
    
    return 0;
}