#include <stdio.h>
#include <omp.h>

int main(int argc, char** argv)
{
	int i= 0, j= 1, k= 1, l= 3;
	printf("i: %d j: %d k: %d l: %d\n", i, j, k, l);	
	
	#pragma omp parallel if(atoi(argv[1])), num_threads(4), default(none), shared(i), firstprivate(j), private(k), reduction(*:l)
	{
		#pragma omp critical
		    ++i;
		printf("Hello world i: %d j: %d k: %d l: %d\n", i, ++j, ++k, ++l);
	}
		
	printf("i: %d j: %d k: %d l: %d\n", i, j, k, l);	
	
	return 0;
}
