#include <filter.h>
#include <math.h>
#include <stdio.h>
#include <float.h>
#include <malloc.h>
#include <stopper.h>
#include <mpi.h>
#include <pthread.h>
#include <unistd.h>

#define MAX(a,b) (a>b?a:b)
#define MIN(a,b) (a<b?a:b)
#define N 3
#define THRESHOLD 0.000001

filter* createGF(float sigma, float theta, float lambda, float psi, float gamma, int stride)
{
  float xtmp, ytmp, xtheta, ytheta, weight;
  int i, j, n, xmax, ymax;
  float sigmax= sigma, sigmay= sigma/gamma;
  filter* f;
  
  xtmp= MAX(fabs(N*sigmax*cos(theta)), fabs(N*sigmay*sin(theta)));
  xtmp= ceil(MAX(1.0, xtmp));
  ytmp= MAX(fabs(N*sigmax*sin(theta)), fabs(N*sigmay*cos(theta)));
  ytmp= ceil(MAX(1.0, ytmp));
  xmax= xtmp;
  ymax= ytmp;
  
  n= (2*xmax + 1)*(2*ymax + 1);
  f= (filter*)malloc(sizeof(filter));
  f->p= (int*)malloc(sizeof(int)*n);
  f->w= (float*)malloc(sizeof(float)*n);
  f->n= 0;
  
  for ( i= -xmax; i <= xmax; ++i )
    for ( j= -ymax; j <= ymax; ++j )
    {
      xtheta= i*cos(theta) + j*sin(theta);
      ytheta= -i*sin(theta) + j*cos(theta);
      
      weight= 1.0/(2*M_PI*sigmax*sigmay)*
	      exp(-0.5*(xtheta*xtheta/(sigmax*sigmax) +
	      ytheta*ytheta/(sigmay*sigmay)));
      if ( weight < THRESHOLD )
	continue;
      weight*= cos(2*M_PI/lambda*xtheta + psi);
      
      f->p[f->n]= i * stride + j;
      f->w[f->n++]= weight;
    }
    
    return f;
}

float applyFn(filter* f, image* input, int n)
{
  int i, imn= (input->rows) * (input->columns);
  float sum= 0;
  
  for ( i= 0; i < f->n; ++i )
    if ( n + f->p[i] >= 0 && n + f->p[i] < imn )
      sum+= (input->content[n + f->p[i]])*(f->w[i]);
    else if ( n + f->p[i] < 0 )
      sum+= (input->content[imn + n + f->p[i]])*(f->w[i]);
    else if ( n + f->p[i] >= imn )
      sum+= (input->content[n + f->p[i] - imn])*(f->w[i]);
    
  return sum;
}

void applyF(filter* f, image* input, image* output)
{
  int i, imn= (input->rows) * (input->columns);
  
  for ( i= 0; i < imn; ++i )
    output->content[i]= applyFn(f, input, i);
}

void destroyF(filter* f)
{
  free(f->p); free(f->w); free(f);
}

filterSet* createGFS(float sigma, int ntheta, float lambda, float psi, float gamma, int stride)
{
  float t, dtheta= M_PI/ntheta;
  
  filterSet* fs= (filterSet*)malloc(sizeof(filterSet));
  fs->f= (filter**)malloc(sizeof(filter*)*ntheta);
  fs->n= 0;
  
  for ( t= 0; t < M_PI; t+= dtheta )
    fs->f[fs->n++]= createGF(sigma, t, lambda, psi, gamma, stride);
  
  return fs;
}

float applyFSn(filterSet* fs, image* input, int n)
{
  float value, maxValue= -FLT_MAX;
  int i;
  
  for ( i= 0; i < fs->n; ++i )
  {
    value= applyFn(fs->f[i], input, n);
    if ( value > maxValue )
      maxValue= value;
  }
  return maxValue;
}

typedef struct schedulerParameter
{
  int* actual;
  int size;
  int imn;
  pthread_mutex_t* mutex;
  int id;
  image* output;
} schedulerParameter;

void* monitor(void* p)
{
  schedulerParameter* parameter= (schedulerParameter*)p;
  while ( 1 )
  {
    pthread_mutex_lock(parameter->mutex);
    if ( *(parameter->actual) < parameter->imn )
    {
      pthread_mutex_unlock(parameter->mutex);
      pthread_exit(NULL);
    }
    printf("%f%%\n", (float)(*(parameter->actual))/(parameter->imn)*100);
    pthread_mutex_unlock(parameter->mutex);
    fflush(stdout);
    sleep(1);
  }
}

void* scheduler(void* p)
{
  schedulerParameter* parameter= (schedulerParameter*)p;
  int range[2];
  
  while ( 1 )
  {
    pthread_mutex_lock(parameter->mutex);
    
    if ( *(parameter->actual) < parameter->imn )
    {
      range[0]= *(parameter->actual);
      range[1]= *(parameter->actual) + parameter->size < parameter->imn ? *(parameter->actual) + parameter->size : parameter->imn;
      (*parameter->actual)+= parameter->size;
    }
    else
      range[0]= range[1]= -1;

    pthread_mutex_unlock(parameter->mutex);
    
    MPI_Send(&range, 2, MPI_INT, parameter->id, 0, MPI_COMM_WORLD);
    
    if ( range[0] == range[1] )
      break;
    
    MPI_Recv(parameter->output->content + range[0], range[1] - range[0], MPI_FLOAT, parameter->id, 0, MPI_COMM_WORLD, NULL);
  }
}

typedef struct workerParameter
{
  int size;
  int* actual;
  int imn;
  image* input;
  image* output;
  filterSet* fs;
  pthread_mutex_t* mutex;
} workerParameter;

void* worker(void* p)
{
  workerParameter* parameter= (workerParameter*)p;
  int begin, end, i;
  
  while( 1 )
  {
    pthread_mutex_lock(parameter->mutex);
    if ( *(parameter->actual) < parameter->imn )
    {
      begin= *(parameter->actual);
      end= *(parameter->actual) + parameter->size < parameter->imn ? *(parameter->actual) + parameter->size : parameter->imn;
      (*parameter->actual)+= parameter->size;
    }
    else
    {
      pthread_mutex_unlock(parameter->mutex);
      pthread_exit(NULL);
    }
    pthread_mutex_unlock(parameter->mutex);

    for ( i= begin; i < end; ++i )
      parameter->output->content[i]= applyFSn(parameter->fs, parameter->input, i);
  }
  pthread_exit(NULL);
}

#define WORKER_THREADS 2
#define MPI_SIZE 10000
#define PTHREAD_SIZE 1000

void applyFS(filterSet* fs, image* input, image* output)
{
  int imn= (input->rows) * (input->columns);
  int rank, range[2]= {0,0};
  
  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  
  if ( rank == 0 )
  {
    int nprocs, actual= 0, i;
    MPI_Comm_size(MPI_COMM_WORLD, &nprocs);
    
    schedulerParameter* parameters= (schedulerParameter*)malloc(sizeof(schedulerParameter)*(nprocs-1));
    pthread_t* ids= (pthread_t*)malloc(sizeof(pthread_t)*(nprocs-1));
    pthread_t monitorId;
    pthread_mutex_t mutex;
    pthread_mutex_init(&mutex, NULL);
    
    for ( i= 0; i < nprocs-1; ++i )
    {
      parameters[i].actual= &actual;
      parameters[i].imn= imn;
      parameters[i].size= MPI_SIZE;
      parameters[i].output= output;
      parameters[i].mutex= &mutex;
      parameters[i].id= i + 1;
    }
    
    pthread_create(&monitorId, NULL, monitor, parameters);
    
    for ( i= 0; i < nprocs-1; ++i )
      pthread_create(ids + i, NULL, scheduler, parameters + i);
    for ( i= 0; i < nprocs-1; ++i )
      pthread_join(ids[i], NULL);
  }
  else
  {
    int i;
    workerParameter parameters[WORKER_THREADS];
    pthread_t ids[WORKER_THREADS];
    int actual;
    pthread_mutex_t mutex;
    pthread_mutex_init(&mutex, NULL);
    
    while ( 1 )
    {
      MPI_Recv( &range, 2, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
      
      if ( range[1] == range[0] )
	break;

      actual= range[0];
      imn= range[1];
      for ( i= 0; i < WORKER_THREADS; ++i )
      {
	parameters[i].actual= &actual;
	parameters[i].imn= imn;
	parameters[i].size= PTHREAD_SIZE;
	parameters[i].input= input;
	parameters[i].output= output;
	parameters[i].fs= fs;
	parameters[i].mutex= &mutex;
      }
      
      for ( i= 0; i < WORKER_THREADS; ++i )
	pthread_create(ids + i, NULL, worker, parameters + i);
      for ( i= 0; i < WORKER_THREADS; ++i )
	pthread_join(ids[i], NULL);
      
      MPI_Send( output->content + range[0], range[1] - range[0], MPI_FLOAT, 0, 0, MPI_COMM_WORLD);
    }
  }
}

void destroyFS(filterSet* fs)
{
  int i;
  for ( i= 0; i < fs->n; ++i )
    destroyF(fs->f[i]);
  
  free(fs->f);
  free(fs);
}
