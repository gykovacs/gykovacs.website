#include <stdio.h>
#include <math.h>
#include <omp.h>

int main()
{
    float a= 2, b= 3, c= 1;
    float x;
    
    #pragma omp parallel num_threads(2)
    {
	#pragma omp sections reduction(min:x)
	{
	    #pragma omp section
	    {
		x= (-b + sqrt(b*b - 4*a*c))/(2*a);
		printf("x1= %f\n", x); fflush(stdout);
	    }
	    #pragma omp section
	    {
		x= (-b - sqrt(b*b - 4*a*c))/(2*a);
		printf("x2= %f\n", x); fflush(stdout);
	    }
	}
    }
    
    printf("A legkisebb megoldas: %f\n", x);
    
    return 0;
}
