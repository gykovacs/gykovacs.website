#! /bin/bash

SIGMAS="1.00 3.00 5.00 7.00 9.00 11.00 13.00 15.00 17.00 19.00"
ANGLES="5 10 15 20 25 30 35 40"
GAMMAS="0.04 0.06 0.11 0.14 0.2 0.33 1 3 5 7 9 15 21"

REPEATS="3"

DIRS="6-3-1-pthreads-mfilter 6-3-6-pthreads-mfilter 6-3-7-pthreads-mfilter"

AF=10
GF=0.06
SF=03.00

OUTPUTDIR="test-results-pthreads"

rm -rf ${OUTPUTDIR}
mkdir ${OUTPUTDIR}

for D in ${DIRS}
do
  OUTPUT0=sigmas-${D}.txt
  OUTPUT1=angles-${D}.txt
  OUTPUT2=gammas-${D}.txt

  touch ${OUTPUTDIR}/${OUTPUT0}
  touch ${OUTPUTDIR}/${OUTPUT1}
  touch ${OUTPUTDIR}/${OUTPUT2}

  cd ${D}
  
  for S in ${SIGMAS}
  do
      echo "dir: ${D} sigma: ${S}"
      for I in `seq 1 1 ${REPEATS}`
      do
	  echo -n ${S} " " >> ../${OUTPUTDIR}/${OUTPUT0}
	  bin/mfilter lena.pgm $S ${AF} ${GF} f1-s${S}-a${AF}-g${GF}-lena.pgm 2 >> ../${OUTPUTDIR}/${OUTPUT0}
      done
  done

  for A in ${ANGLES}
  do
      echo "dir: ${D} angle: ${A}"
      for I in `seq 1 1 ${REPEATS}`
      do
	  echo -n ${A} " " >> ../${OUTPUTDIR}/${OUTPUT1}
	  bin/mfilter lena.pgm ${SF} ${A} ${GF} f2-s${SF}-a${A}-g${GF}-lena.pgm 2 >> ../${OUTPUTDIR}/${OUTPUT1}
      done
  done

  for G in ${GAMMAS}
  do
      echo "dir: ${D} gamma: ${G}"
      for I in `seq 1 1 ${REPEATS}`
      do
	  echo -n ${G} " " >> ../${OUTPUTDIR}/${OUTPUT2}
	  bin/mfilter lena.pgm ${SF} ${AF} ${G} f3-s${SF}-a${AF}-g${G}-lena.pgm 2 >> ../${OUTPUTDIR}/${OUTPUT2}
      done
  done
  
  cd ..
done

cp figures-pthreads.R ${OUTPUTDIR}
cd ${OUTPUTDIR}
Rscript figures-pthreads.R 3
cd ..
