#include <stdio.h>
#include <stdlib.h>
#include <filter.h>
#include <pgm.h>
#include <image.h>
#include <stopper.h>

int main(int argc, char** argv)
{
  if ( argc < 6 )
    return printf("Hasznalat: %s <input.pgm> sigma ntheta gamma <output.pgm> threads\n", argv[0]);
    
  float sigma, gamma;
  int ntheta;
  image* input, *output;
  stopperOMP st;
  
  startSOMP(&st);
  
  sigma= atof(argv[2]);
  ntheta= atoi(argv[3]);
  gamma= atof(argv[4]);
  threads= atoi(argv[6]);

  input= readPGMImage(argv[1]);
  output= createI(input->rows, input->columns);
  filterSet* gfs= createGFS(sigma, ntheta, 9, 0, gamma, input->columns);
  
  applyFS(gfs, input, output);
  
  writePGMImage(argv[5], output);
  
  destroyI(input);
  destroyI(output);
  destroyFS(gfs);

  stopSOMP(&st);
  tprintfOMP(&st, "\n");
  
  return 0;
}
