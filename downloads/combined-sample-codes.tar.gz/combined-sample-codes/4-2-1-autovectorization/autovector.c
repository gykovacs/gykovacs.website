#include <stdlib.h>
#define N 1024

char a[N], b[N], c[N];

int main()
{
	int i;
	
	for ( i= 0; i < N; ++i )
	{
	    b[i]= rand()%128;
	    c[i]= rand()%128;
	}
	
	for ( i= 0; i < N; ++i )
	    a[i]= b[i] + c[i];
		
	return 0;
}
