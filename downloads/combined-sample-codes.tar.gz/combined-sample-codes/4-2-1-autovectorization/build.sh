#!/bin/bash

gcc -o autovector autovector.c -O3 -ftree-vectorizer-verbose=6 -march=native --fast-math