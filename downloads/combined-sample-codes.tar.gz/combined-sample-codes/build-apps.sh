#! /bin/bash

for I in `ls -d */`
do
  if [[ -f ${I}/CMakeLists.txt ]]
  then
    cd ${I}
    cmake -DCMAKE_BUILD_TYPE=release -r .
    make
    cd ..
  fi
done