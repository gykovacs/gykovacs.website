#include <stdio.h>
#include <math.h>
#include <omp.h>

int main(int argc, char** argv)
{
    int i, j= 0;
    
    #pragma omp parallel num_threads(2)
    {
	printf("%d indexu szal elindult.\n", omp_get_thread_num());
	fflush(stdout);
	
	if ( omp_get_thread_num() == 0 )
	    #pragma omp task final(atoi(argv[1]))
	    {
		int g= omp_get_thread_num();
		printf("A final(%d) taszk vegrehajtasa\n"\
			"\tGeneralo szal: 0.\n"\
			"\tVegrehajto szal: %d\n", atoi(argv[1]), omp_get_thread_num());
		fflush(stdout);
		#pragma omp task firstprivate(g)
		{
		    printf("B taszk - Ez a taszk kerulhet beagyazasra a szulo A taszkba\n"\
			    "\tGeneralo szal: %d.\n"\
			    "\tVegrehajto szal: %d\n", g, omp_get_thread_num());
		    fflush(stdout);
		}
		printf("Final taszk befejezodott.\n");
		fflush(stdout);
	    }
	    
	if ( omp_get_thread_num() == 1 )
	    #pragma omp task if(atoi(argv[2]))
	    {
		printf("C if(%d) taszk vegrehajtasa\n"\
			"\tGeneralo szal: 1.\n"
			"\tVegrehajto szal: %d\n", atoi(argv[2]), omp_get_thread_num());
		fflush(stdout);
	    }
	
	printf("%d indexu szal befejezodott.\n", omp_get_thread_num());
	fflush(stdout);
    }
    
    return 0;
}