#include <vector.h>
#include <sampler.h>
#include <knnalg.h>
#include <stopper.h>

int main(int argc, char** argv)
{
  vectorSet vs;
  vector v;
  unsigned int label;
  int error;
  int i;
  stopper st;
  
  if ( argc == 13 )
  {
    printf("Valos adatok beolvasasa: %s\n", argv[2]); fflush(stdout);
    error= readCVS(&vs, argv[2]);
    if ( error )
    {
	fputs("Nem sikerult megnyitni a fajlt!\n", stderr);
	return 0;
    }
    createV(&v, 10);
    for ( i= 0; i < 10; ++i )
	v.data[i]= atof(argv[i+3]);
  }
  else if ( argc == 4 )
  {
    printf("Mintavetelezes.\n"); fflush(stdout);
    sampleVS(&vs, atoi(argv[2]), atoi(argv[3]));
    sampleV(&v, atoi(argv[3]));
  }
  else
  {
    printf("Hasznalat:\n");
    printf("\t %s k N dim\n", argv[0]);
    printf("\t %s k MAGIC_adatfajl v0 v1 v2 v3 v4 v5 v6 v7 v8 v9\n", argv[0]);
    return 0;
  }

  startS(&st);
  label= knnalg(&v, &vs, atoi(argv[1]), distanceEUC);
  stopS(&st);  
  printf("Label: %d\n", label);
  
  tprintf(&st, "\n");
  
  return 0;
}
