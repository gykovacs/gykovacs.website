#include <sampler.h>
#include <string.h>
#include <stdio.h>

#define ATTRIBUTE_RANGE 10
#define NUM_CLASSES 2

void sampleVS(vectorSet* vs, int numVectors, int numCoords)
{
  unsigned int i, j;
  createVSn(vs, numVectors);
  srand(time(NULL));
  for ( i= 0; i < numVectors; ++i )
    sampleV(vs->data + i, numCoords);
  vs->numClass= 2;
}

void sampleV(vector* v, int numCoords)
{
    unsigned int i;
    createV(v, numCoords);
    
    for ( i= 0; i < numCoords; ++i )
	v->data[i]= rand() % ATTRIBUTE_RANGE;
    v->label= rand() % NUM_CLASSES;
}

int readCVS(vectorSet* vs, char* filename)
{
  FILE* file= fopen(filename, "r");
  char buffer[1000];
  vector v;
  unsigned int i;
  char* tmp;
  
  createV(&v, 10);
  createVS(vs);
  
  if ( file == NULL )
  {
    fputs("File read error...\n", stderr);
    return 0;
  }
  
  while ( fgets(buffer, 1000, file) != NULL )
  {
    fgets(buffer, 1000, file);
    tmp= strtok(buffer, ",");
    for ( i= 0; i < 10; ++i )
    {
	v.data[i]= atof(tmp);
	tmp= strtok(NULL, ",");
	fflush(stdout);
    }
    if ( *tmp == 'g' )
        v.label= 0;
    else
	v.label= 1;
    addVectorToVS(&v, vs);
  }
  
  vs->numClass= 2;
  
  destroyV(&v);
  
  return 0;
}
