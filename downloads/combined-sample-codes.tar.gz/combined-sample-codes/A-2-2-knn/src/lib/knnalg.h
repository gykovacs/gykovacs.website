#ifndef _KNN_ALG_H_
#define _KNN_ALG_H_

#include <vector.h>

/** a kNN algoritmus megvalositasa
    * @param v ismeretlen cimkeju input vektor
    * @param vs tanulo vektorokat tartalmazo vektor halmaz
    * @param k a kNN osztalyozas k parametere
    * @param distance tavolsagfuggveny
    * @returns a v vektor valoszinusitett osztaly-cimkeje
    */
unsigned char knnalg(vector* v, vectorSet* vs, int k, float (*distance)(vector*, vector*));

#endif
