#ifndef _VECTOR_H_
#define _VECTOR_H_

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>

/** vektor tipus*/
typedef struct vector
{
  float* data;		/// a vektor elemeit tartalmazo tomb
  unsigned int n;	/// a vektor elemeinek szama
  unsigned char label;	/// a vektor osztalya
} vector;

/** vektor halmaz tipus*/
typedef struct vectorSet
{
  vector* data;		/// a vektor halmaz elemei
  unsigned int n;	/// a vektor halmaz szamossaga
  int capacity;		/// kapacitas (teljes lefoglalt terulet)
  unsigned int numClass;	/// a kulonbozo osztalycimkek szama
} vectorSet;

/** vektor tipusu valtozo inicializalasa
    * @param v a vektor valtozo cime
    * @param n a vektor dimenzionalitasa
    */
void createV(vector* v, unsigned int n);

/** n dimenzionalitasu vektor tipusu valtozo inicializalasa
    * @param v a vektor valtozo cime
    * @param n a vektor dimenzionalitasa
    */
void createVn(vector* v, unsigned int n, ...);

/** vektor valtozo felszabaditasa
    * @param v a vektor valtozo cime
    */
void destroyV(vector* v);

/** vektorhalmaz inicializalasa
    * @param vs a vektor halmaz valtozo cime
    */
void createVS(vectorSet* vs);

/** vektorhalmaz inicializalasa n vektor tarolasara
    * @param vs a vektorhalmaz cime
    * @param n a vektorhalmaz elemeinek szama
    */
void createVSn(vectorSet* vs, unsigned int n);

/** vektorhalmaz felszabaditasa
    * @param vs a vektorhalmaz cime
    */
void destroyVS(vectorSet* vs);

/** vektor hozzaadasa vektorhalmazhoz
    * @param v a vektor cime
    * @param vs a vektorhalmaz cime
    */
void addVectorToVS(vector* v, vectorSet* vs);

/** cimkezett vektor kiirasa
    * @param v a vektor valtozo cime
    */
void printV(vector* v);

/** Euklideszi-tavolsag fuggveny
    * @param v1 elso vektor cime
    * @param v2 masodik vektor cime
    * @returns a vektorok Euklideszi-tavolsaga
    */
float distanceEUC(vector* v1, vector* v2);

/** Hamming-tavolsag fuggveny
    * @param v1 elso vektor cime
    * @param v2 masodik vektor cime
    * @returns a vektorok Hamming-tavolsaga
    */
float distanceHAM(vector* v1, vector* v2);

#endif 
