#include <knnalg.h>
#include <float.h>

unsigned char knnalg(vector* v, vectorSet* vs, int k, float (*distance)(vector*, vector*))
{
  float* distances= (float*)malloc(sizeof(float)*(vs->n));
  unsigned int i;
  int minIdx;
  int maxIdx;
  unsigned int* labels= (unsigned int*)malloc(sizeof(unsigned int)*(vs->numClass));
  
  // tavolsagok meghatarozasa
  for ( i= 0; i < vs->n; ++i )
    distances[i]= distance(v, vs->data + i);
  
  for ( i= 0; i < vs->numClass; ++i )
    labels[i]= 0;

  // k legkozelebbi vektor megkeresese es cimkeik regisztralasa
  for ( ; k > 0; --k )
  {
    minIdx= 0;
    for ( i= 0; i < vs->n; ++i )
      if ( distances[i] < distances[minIdx] )
	minIdx= i;
    labels[vs->data[minIdx].label]++;
    distances[minIdx]= FLT_MAX;
  }

  // az eredmeny cimke meghatarozasa
  maxIdx= 0;
  for ( i= 0; i < vs->numClass; ++i )
  {
    printf("Label: %d - neighbors: %d\n", i, labels[i]);
    if ( labels[i] > labels[maxIdx] )
      maxIdx= i;
  }

  free(distances);
  free(labels);
  
  return maxIdx;
}
