#ifndef _SAMPLER_
#define _SAMPLER_

#include <vector.h>

/** vektor halmaz veletlenszeru generalasa
    * @param vs a vektorhalmaz valtozo cime
    * @param numVectors a vektorok szama
    * @param numCoords a vektorok dimenzionalitasa
    */
void sampleVS(vectorSet* vs, int numVectors, int numCoords);

/** veletlen vektor generalasa
    * @param v a vektor valtozo cime
    * @param numCoords a vektor dimenzionalitasa
    */
void sampleV(vector* v, int numCoords);

/** a MAGIC adatokat tartalmazo CSV fajl beolvasasa
    * @param vs a vektorhalmaz valtozo cime
    * @param filename a CSV fajl neve eleresi uttal
    * @returns 0 ha a beolvasas sikeres, hiba eseten 1
    */
int readCVS(vectorSet* vs, char* filename);

#endif