#include <vector.h>
#include <stdarg.h>

void createV(vector* v, unsigned int n)
{
  v->data= (float*)malloc(sizeof(float)*n);
  v->n= n;
}

void createVn(vector* v, unsigned int n,  ...)
{
  unsigned int i;
  
  createV(v, n);
  
  va_list ap;
  va_start(ap, n);
  
  for ( i= 0; i < n; ++i )
  {
    v->data[i]= va_arg(ap, double);
  }
  va_end(ap);
}

void destroyV(vector* v)
{
  free(v->data);
  v->data= NULL;
  v->n= 0;
}

void createVS(vectorSet* vs)
{
    vs->data= (vector*)malloc(sizeof(vector)*100);
    vs->n= 0;
    vs->capacity= 100;
}

void createVSn(vectorSet* vs, unsigned int n)
{
  vs->data= (vector*)malloc(sizeof(vector)*(n + 100));
  vs->n= n;
  vs->capacity= n + 100;
}

void destroyVS(vectorSet* vs)
{
  unsigned int i;
  for ( i= 0; i < vs->n; ++i )
    destroyV(vs->data + i);
  free(vs->data);
  vs->n= 0;
}

void addVectorToVS(vector* v, vectorSet* vs)
{
  unsigned int i;
  if ( vs->n == vs->capacity )
  {
    vs->data= (vector*)realloc(vs->data, sizeof(vector)*(vs->capacity + 100));
    vs->capacity= vs->capacity + 100;
  }
  createV(vs->data + vs->n, v->n);
  for ( i= 0; i < v->n; ++i )
    vs->data[vs->n].data[i]= v->data[i];
  vs->data[vs->n++].label= v->label;
}

void printV(vector* v)
{
  unsigned int i;
  printf("[");
  for ( i= 0; i < v->n; ++i )
    printf("%f ", v->data[i]);
  printf("- %d ]\n", v->label);
  fflush(stdout);
}

float distanceEUC(vector* v1, vector* v2)
{
  unsigned int i;
  float res= 0;
  for ( i= 0; i < v1->n; ++i )
    res+= (v1->data[i] - v2->data[i])*(v1->data[i] - v2->data[i]);
  return res;
}

float distanceHAM(vector* v1, vector* v2)
{
  unsigned int i;
  float res= 0;
  for ( i= 0; i < v1->n; ++i )
    if ( fabs(v1->data[i] - v2->data[i]) > res )
      res= fabs(v1->data[i] - v2->data[i]);
  return res;
}
