#ifndef _STOPPER_H_
#define _STOPPER_H_

#include <time.h>

typedef struct stopper
{
	clock_t begin;
	clock_t end;
} stopper;

void startS(stopper* st);

void stopS(stopper* st);

int tprintf(stopper* st, const char* fmt, ...);

#endif
