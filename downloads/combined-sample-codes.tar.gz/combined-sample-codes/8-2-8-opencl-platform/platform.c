#include <stdio.h>
#include <CL/opencl.h>
#include <error.h>

#define MAX_PLATFORMS 10
#define MAX_DEVICES 10
#define MAX_STRING_SIZE 1000

int main(int argc, char** argv)
{
  cl_int err;
  cl_uint numPlatforms;
  cl_platform_id platforms[MAX_PLATFORMS];
  char pString[MAX_STRING_SIZE];
  size_t size;
  int i;

  err= clGetPlatformIDs(MAX_PLATFORMS, platforms, &numPlatforms);
  ERROR(err, "clGetPlatformIDs");

  printf("Number of platforms: %d\n", numPlatforms);
  for ( i= 0; i < numPlatforms; ++i )
  {
    err= clGetPlatformInfo(platforms[i], CL_PLATFORM_NAME, MAX_STRING_SIZE, pString, &size);
    ERROR(err, "clGetPlatformInfo");
    printf("Platform name: %s\n", pString);
    err= clGetPlatformInfo(platforms[i], CL_PLATFORM_VENDOR, MAX_STRING_SIZE, pString, &size);
    ERROR(err, "clGetPlatformInfo");
    printf("Platform vendor: %s\n", pString);
    err= clGetPlatformInfo(platforms[i], CL_PLATFORM_VERSION, MAX_STRING_SIZE, pString, &size);
    ERROR(err, "clGetPlatformInfo");
    printf("Platform version: %s\n", pString);
    err= clGetPlatformInfo(platforms[i], CL_PLATFORM_PROFILE, MAX_STRING_SIZE, pString, &size);
    ERROR(err, "clGetPlatformInfo");
    printf("Platform profile: %s\n", pString);
    err= clGetPlatformInfo(platforms[i], CL_PLATFORM_EXTENSIONS, MAX_STRING_SIZE, pString, &size);
    ERROR(err, "clGetPlatformInfo");
    printf("Platform extensions: %s\n", pString);
  }
   
  return 0;
}