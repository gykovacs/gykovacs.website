#include <filter.h>
#include <math.h>
#include <stdio.h>
#include <float.h>
#include <malloc.h>
#include <stopper.h>

#define MAX(a,b) (a>b?a:b)
#define N 3
#define THRESHOLD 0.000001

filter* createGF(float sigma, float theta, float lambda, float psi, float gamma, int stride)
{
  float xtmp, ytmp, xtheta, ytheta, weight;
  int i, j, n, xmax, ymax;
  float sigmax= sigma, sigmay= sigma/gamma;
  filter* f;
  
  xtmp= MAX(fabs(N*sigmax*cos(theta)), fabs(N*sigmay*sin(theta)));
  xtmp= ceil(MAX(1.0, xtmp));
  ytmp= MAX(fabs(N*sigmax*sin(theta)), fabs(N*sigmay*cos(theta)));
  ytmp= ceil(MAX(1.0, ytmp));
  xmax= xtmp;
  ymax= ytmp;
  
  n= (2*xmax + 1)*(2*ymax + 1);
  f= (filter*)malloc(sizeof(filter));
  f->p= (int*)malloc(sizeof(int)*n);
  f->w= (float*)malloc(sizeof(float)*n);
  f->n= 0;
  
  for ( i= -xmax; i <= xmax; ++i )
    for ( j= -ymax; j <= ymax; ++j )
    {
      xtheta= i*cos(theta) + j*sin(theta);
      ytheta= -i*sin(theta) + j*cos(theta);
      
      weight= 1.0/(2*M_PI*sigmax*sigmay)*
	      exp(-0.5*(xtheta*xtheta/(sigmax*sigmax) +
	      ytheta*ytheta/(sigmay*sigmay)));
      if ( weight < THRESHOLD )
	continue;
      weight*= cos(2*M_PI/lambda*xtheta + psi);
      
      f->p[f->n]= i * stride + j;
      f->w[f->n++]= weight;
    }
    
    return f;
}

float applyFn(filter* f, image* input, int n)
{
  int i, imn= (input->rows) * (input->columns);
  float sum= 0;
  
  for ( i= 0; i < f->n; ++i )
    if ( n + f->p[i] >= 0 && n + f->p[i] < imn )
      sum+= (input->content[n + f->p[i]])*(f->w[i]);
    else if ( n + f->p[i] < 0 )
      sum+= (input->content[imn + n + f->p[i]])*(f->w[i]);
    else if ( n + f->p[i] >= imn )
      sum+= (input->content[n + f->p[i] - imn])*(f->w[i]);
    
  return sum;
}

void applyF(filter* f, image* input, image* output)
{
  int i, imn= (input->rows) * (input->columns);
  
  for ( i= 0; i < imn; ++i )
    output->content[i]= applyFn(f, input, i);
}

void destroyF(filter* f)
{
  free(f->p); free(f->w); free(f);
}

filterSet* createGFS(float sigma, int ntheta, float lambda, float psi, float gamma, int stride)
{
  float t, dtheta= M_PI/ntheta;
  
  filterSet* fs= (filterSet*)malloc(sizeof(filterSet));
  fs->f= (filter**)malloc(sizeof(filter*)*ntheta);
  fs->n= 0;
  
  for ( t= 0; t < M_PI; t+= dtheta )
    fs->f[fs->n++]= createGF(sigma, t, lambda, psi, gamma, stride);
  
  return fs;
}

float applyFSn(filterSet* fs, image* input, int n)
{
  float value, maxValue= -FLT_MAX;
  int i;
  
  for ( i= 0; i < fs->n; ++i )
  {
    value= applyFn(fs->f[i], input, n);
    if ( value > maxValue )
      maxValue= value;
  }
  return maxValue;
}

void applyFS(filterSet* fs, image* input, image* output)
{
  int imn= (input->rows) * (input->columns);
  int i;
  
  for ( i= 0; i < imn; ++i )
    output->content[i]= applyFSn(fs, input, i);
}

void destroyFS(filterSet* fs)
{
  int i;
  for ( i= 0; i < fs->n; ++i )
    destroyF(fs->f[i]);
  
  free(fs->f);
  free(fs);
}
