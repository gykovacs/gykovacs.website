#! /bin/bash

cmake -DCMAKE_C_FLAGS="-O3 -ftree-vectorizer-verbose=6 -march=native --fast-math"
make clean
make
