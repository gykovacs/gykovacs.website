#include <pthread.h>
#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>
#include <error.h>

typedef struct parameter
{
    char* sztring;
    int id;
} parameter;

void* szal(void* p)
{
    parameter* par= (parameter*)p;
    printf("%d. parancssori argumentum: %s\n", par->id, par->sztring); fflush(stdout);
    return NULL;
}

int main(int argc, char** argv)
{
    int i, err;
    pthread_t* ids= (pthread_t*)malloc(sizeof(pthread_t)*argc);
    parameter* par= (parameter*)malloc(sizeof(parameter)*argc);
    for ( i= 0; i < argc; ++i )
    {
	par[i].sztring= argv[i];
	par[i].id= i;
	err= pthread_create(ids + i, NULL, szal, par + i);
	ERROR(err, "pthread_create");
    }
    
    for ( i= 0; i < argc; ++i )
    {
	err= pthread_join(ids[i], NULL);
	ERROR(err, "pthread_create");
    }

    free(ids);
    free(par);

    return 0;    
}
