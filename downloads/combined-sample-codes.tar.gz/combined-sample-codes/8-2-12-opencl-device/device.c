#include <stdio.h>
#include <error.h>
#include <CL/opencl.h>

#define MAX_PLATFORMS 10
#define MAX_DEVICES 10
#define MAX_STRING_SIZE 1000

int main(int argc, char** argv)
{
  cl_int err;
  cl_uint numPlatforms;
  cl_platform_id platforms[MAX_PLATFORMS];
  cl_uint numDevices;
  cl_device_id devices[MAX_DEVICES];
  char pString[MAX_STRING_SIZE];
  cl_device_type pcdt;
  cl_uint puint;
  size_t psize;
  cl_ulong pulong;
  cl_bool pbool;
  cl_context context;
  cl_context_properties properties[MAX_PLATFORMS*2]= {0};
  size_t size;
  int i, j;
  size_t t[3];

  err= clGetPlatformIDs(MAX_PLATFORMS, platforms, &numPlatforms);
  ERROR(err, "clGetPlatformIDs");

  printf("Number of platforms: %d\n", numPlatforms);
  for ( i= 0; i < numPlatforms; ++i )
  {
    err= clGetPlatformInfo(platforms[i], CL_PLATFORM_NAME, MAX_STRING_SIZE, pString, &size);
    ERROR(err, "clGetPlatformInfo");
    printf("Platform name: %s\n", pString);
    err= clGetPlatformInfo(platforms[i], CL_PLATFORM_VENDOR, MAX_STRING_SIZE, pString, &size);
    ERROR(err, "clGetPlatformInfo");
    printf("Platform vendor: %s\n", pString);
    
    err= clGetDeviceIDs(platforms[i], CL_DEVICE_TYPE_ALL, MAX_DEVICES, devices, &numDevices);
    ERROR(err, "clGetDeviceIDs");
    
    printf("Number of devices in platform %d: %d\n", platforms[i], numDevices);
    for ( j= 0; j < numDevices; ++j )
    {
      err= clGetDeviceInfo(devices[j], CL_DEVICE_TYPE, sizeof(cl_device_type), &pcdt, &size);
      ERROR(err, "clGetDeviceInfo");
      if ( pcdt & CL_DEVICE_TYPE_CPU ) printf("\t Device type: CL_DEVICE_TYPE_CPU\n");
      if ( pcdt & CL_DEVICE_TYPE_GPU ) printf("\t Device type: CL_DEVICE_TYPE_GPU\n");
      if ( pcdt & CL_DEVICE_TYPE_ACCELERATOR ) printf("\t Device type: CL_DEVICE_TYPE_ACCELERATOR\n");
      if ( pcdt & CL_DEVICE_TYPE_DEFAULT ) printf("\t Device type: CL_DEVICE_TYPE_DEFAULT\n");
      if ( pcdt & CL_DEVICE_TYPE_CUSTOM ) printf("\t Device type: CL_DEVICE_TYPE_CUSTOM\n");

      err= clGetDeviceInfo(devices[j], CL_DEVICE_MAX_COMPUTE_UNITS, sizeof(cl_uint), &puint, &size);
      ERROR(err, "clGetDeviceInfo");
      printf("\t Device max compute units: %d\n", puint);

      err= clGetDeviceInfo(devices[j], CL_DEVICE_MAX_WORK_GROUP_SIZE, sizeof(psize), &psize, &size);
      ERROR(err, "clGetDeviceInfo");
      printf("\t Device max work group size: %d\n", psize);
      
      err = clGetDeviceInfo(devices[j], CL_DEVICE_MAX_WORK_ITEM_DIMENSIONS, sizeof(cl_uint), &puint, &size);
      ERROR(err, "clGetDeviceInfo");
      printf("\t Device max work item dimensions: %d\n", puint);
      
      err= clGetDeviceInfo(devices[j], CL_DEVICE_MAX_WORK_ITEM_SIZES, sizeof(size_t)*3, &t, &size);
      ERROR(err, "clGetDeviceInfo");
      printf("\t Device max work item sizes: %d %d %d\n", t[0], t[1], t[2]);
      
      err= clGetDeviceInfo(devices[j], CL_DEVICE_GLOBAL_MEM_SIZE, sizeof(cl_ulong), &pulong, &size);
      ERROR(err, "clGetDeviceInfo");
      printf("\t Device max global mem size: %d\n", pulong);
      
      err= clGetDeviceInfo(devices[j], CL_DEVICE_GLOBAL_MEM_CACHE_SIZE, sizeof(cl_ulong), &pulong, &size);
      ERROR(err, "clGetDeviceInfo");
      printf("\t Device max global mem cache size: %d\n", pulong);
      
      err= clGetDeviceInfo(devices[j], CL_DEVICE_MAX_CONSTANT_BUFFER_SIZE, sizeof(cl_ulong), &pulong, &size);
      ERROR(err, "clGetDeviceInfo");
      printf("\t Device max constant buffer size: %d\n", pulong);
      
      err= clGetDeviceInfo(devices[j], CL_DEVICE_LOCAL_MEM_SIZE, sizeof(cl_ulong), &pulong, &size);
      ERROR(err, "clGetDeviceInfo");
      printf("\t Device max local mem size: %d\n", pulong);
      
      err= clGetDeviceInfo(devices[j], CL_DEVICE_PRINTF_BUFFER_SIZE, sizeof(size_t), &psize, &size);
      ERROR(err, "clGetDeviceInfo");
      printf("\t Device printf buffer size: %d\n", psize);
      
      err= clGetDeviceInfo(devices[j], CL_DEVICE_AVAILABLE, sizeof(cl_bool), &pbool, &size);
      ERROR(err, "clGetDeviceInfo");
      printf("\t Device available: %d\n", pbool);
      
      err= clGetDeviceInfo(devices[j], CL_DEVICE_COMPILER_AVAILABLE, sizeof(cl_bool), &pbool, &size);
      ERROR(err, "clGetDeviceInfo");
      printf("\t Device compiler available: %d\n", pbool);
      
      err= clGetDeviceInfo(devices[j], CL_DEVICE_LINKER_AVAILABLE, sizeof(cl_bool), &pbool, &size);
      ERROR(err, "clGetDeviceInfo");
      printf("\t Device linker available: %d\n", pbool);
      
      err= clGetDeviceInfo(devices[j], CL_DEVICE_NAME, MAX_STRING_SIZE, &pString, &size);
      ERROR(err, "clGetDeviceInfo");
      printf("\t Device name: %s\n", pString);
      
      err= clGetDeviceInfo(devices[j], CL_DEVICE_VENDOR, MAX_STRING_SIZE, &pString, &size);
      ERROR(err, "clGetDeviceInfo");
      printf("\t Device vendor: %s\n", pString);
      
      err= clGetDeviceInfo(devices[j], CL_DEVICE_VERSION, MAX_STRING_SIZE, &pString, &size);
      ERROR(err, "clGetDeviceInfo");
      printf("\t Device version: %s\n", pString);
      
      err= clGetDeviceInfo(devices[j], CL_DRIVER_VERSION, MAX_STRING_SIZE, &pString, &size);
      ERROR(err, "clGetDeviceInfo");
      printf("\t Driver version: %s\n", pString);
      
      err= clGetDeviceInfo(devices[j], CL_DEVICE_OPENCL_C_VERSION, MAX_STRING_SIZE, &pString, &size);
      ERROR(err, "clGetDeviceInfo");
      printf("\t Device OpenCL C version: %s\n", pString);
    }
  }
  
  return 0;
}