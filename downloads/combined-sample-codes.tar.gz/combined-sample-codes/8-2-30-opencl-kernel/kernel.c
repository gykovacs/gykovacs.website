#include <stdio.h>
#include <stdlib.h>
#include <error.h>
#include <kernelio.h>
#include <CL/opencl.h>

#define MAX_DEVICES 2
#define MAX_PLATFORMS 2

void notify(const char* errinfo, const void* private_info, size_t cb, void* user_data)
{
  fprintf(*(FILE**)user_data, "CALLBACK NOTIFICATION: %s\n", errinfo);
}

int main(int argc, char** argv)
{
  cl_int err;
  cl_context context;
  cl_command_queue queue;
  cl_uint numPlatforms;
  cl_platform_id platforms[MAX_PLATFORMS];
  cl_uint numDevices;
  cl_device_id devices[MAX_DEVICES];
  cl_context_properties properties[3]= {0};
  size_t size;
  cl_program program, program2;
  char* source;
  size_t sourceLength;
  unsigned char** binaryCodes, **binaryCodes2;
  size_t* binaryLengths, *binaryLengths2;
  cl_int* binaryStatus;
  cl_uint n= 0, n2= 0;
  int i;
  
  err= clGetPlatformIDs(MAX_PLATFORMS, platforms, &numPlatforms);
  ERROR(err, "clGetPlatformIDs");
  
  properties[0]= (cl_context_properties)CL_CONTEXT_PLATFORM;
  properties[1]= (cl_context_properties)(platforms[0]);
  properties[2]= 0;
  
  context= clCreateContextFromType(properties, CL_DEVICE_TYPE_ALL, notify, &stderr, &err);
  ERROR(err, "clCreateContextFromType");
  
  err= clGetContextInfo(context, CL_CONTEXT_DEVICES, MAX_DEVICES*sizeof(cl_device_id), devices, &size);
  ERROR(err, "clGetContextInfo");
  err= clGetContextInfo(context, CL_CONTEXT_NUM_DEVICES, sizeof(cl_uint), &numDevices, &size);
  ERROR(err, "clGetContextInfo");
  
  queue= clCreateCommandQueue(context, devices[0], 0, &err);
  ERROR(err, "clCreateCommandQueue");
  
  readSourceProgram(argv[1], &source, &sourceLength);
  
  program= clCreateProgramWithSource(context, 1, &source, &sourceLength, &err);
  ERROR(err, "clCreateProgramWithSource");
  
  err= clBuildProgram(program, 1, devices, "-cl-fast-relaxed-math", NULL, NULL);
  ERROR(err, "clBuildProgram");

  err= clGetProgramInfo(program, CL_PROGRAM_NUM_DEVICES, sizeof(n), &n, &size);
  ERROR(err, "clGetProgramInfo");
  
  binaryLengths= (size_t*)malloc(sizeof(size_t)*n);
  binaryCodes= (unsigned char**)malloc(sizeof(unsigned char*)*n);
  
  err= clGetProgramInfo(program, CL_PROGRAM_BINARY_SIZES, sizeof(size_t)*n, binaryLengths, &size);
  ERROR(err, "clGetProgramInfo");

  for ( i= 0; i < n; ++i )
    binaryCodes[i]= (unsigned char*)malloc(sizeof(unsigned char)*(binaryLengths[i]));

  err= clGetProgramInfo(program, CL_PROGRAM_BINARIES, sizeof(unsigned char*)*n, binaryCodes, &size);
  ERROR(err, "clGetProgramInfo");

  writeBinaryProgram(argv[2], binaryCodes, binaryLengths, n);
  readBinaryProgram(argv[2], &binaryCodes2, &binaryLengths2, &n2);

  binaryStatus= (cl_int*)malloc(sizeof(cl_int)*n);
  program2= clCreateProgramWithBinary(context, 1, devices, binaryLengths2, binaryCodes2, binaryStatus, &err);
  ERROR(err, "clCreateProgramWithBinary");

  clReleaseProgram(program);
  clReleaseProgram(program2);
  clReleaseCommandQueue(queue);
  clReleaseContext(context);
  
  free(source);
  for ( i= 0; i < n; ++i )
  {
    free(binaryCodes[i]);
    free(binaryCodes2[i]);
  }
  free(binaryCodes);
  free(binaryCodes2);
  free(binaryLengths);
  free(binaryLengths2);
  
  return 0;
}
