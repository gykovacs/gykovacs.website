#include <control.h>
#include <simulation.h>
#include <stopper.h>
#include <stdlib.h>

int main(int argc, char** argv)
{
  if ( argc != 3 )
    return printf("Hasznalat: %s <N> <dt>\n", argv[0]);
  
  N= atoi(argv[1]);
  dt= atof(argv[2]);
  
  // objektumok inicializalasa
  initObjects();
  
  // OpenGL kornyezet inicializalasa
  glInit(argc, argv);
  
  // vizualizacios ciklus inditasa
  glutMainLoop();

  // lefoglalt eroforrasok felszabaditasa
  destroyObjects();
  
  return 0;
}
