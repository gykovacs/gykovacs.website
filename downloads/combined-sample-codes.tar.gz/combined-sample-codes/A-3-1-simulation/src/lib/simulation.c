#include <simulation.h>
#include <math.h>
#include <float.h>
#include <stdlib.h>
#include <stopper.h>
#include <GL/glut.h>

void initObjects()
{
  r= (float*)malloc(sizeof(float)*N*3);
  v= (float*)malloc(sizeof(float)*N*3);
  tmp= (float*)malloc(sizeof(float)*N*3);
  m= (float*)malloc(sizeof(float)*N);
  int i;
  for ( i= 0; i < 3*N; i+= 3 )
  {
    r[i]= ((float)rand())/RAND_MAX*2-1;
    r[i+1]= ((float)rand())/RAND_MAX*2-1;
    r[i+2]= ((float)rand())/RAND_MAX*2-1;
    m[i/3]= ((float)rand())/RAND_MAX;
    v[i]= ((float)rand())/RAND_MAX*2-1;
    v[i+1]= ((float)rand())/RAND_MAX*2-1;
    v[i+2]= ((float)rand())/RAND_MAX*2-1;
  }
}

void destroyObjects()
{
  free(r);
  free(v);
  free(tmp);
  free(m);
}

void oneIteration()
{
  int i, j, k;
  float ax, ay, az;
  float dx, dy, dz;
  float ir;
  float ir3;
  float f;
  stopper st;
  startS(&st);
  for ( i= 0; i < 3*N; i+= 3 )
  {
    ax= ay= az= 0.0f;
    for ( j= 0; j < 3*N; j+= 3 )
    {
      dx= r[j]-r[i];
      dy= r[j+1]-r[i+1];
      dz= r[j+2]-r[i+2];
      
      ir= 1.0/sqrt(dx*dx + dy*dy + dz*dz + 0.001);
      ir3= ir*ir*ir;
      f= m[j/3]*ir3;
      
      ax+= f*dx;
      ay+= f*dy;
      az+= f*dz;
    }
    
    tmp[i]= r[i] + dt*v[i] + 0.5*dt*dt*ax;
    tmp[i+1]= r[i+1] + dt*v[i+1] + 0.5*dt*dt*ay;
    tmp[i+2]= r[i+2] + dt*v[i+2] + 0.5*dt*dt*az;
    
    v[i]+= dt*ax;
    v[i+1]+= dt*ay;
    v[i+2]+= dt*az;
  }
  for ( i= 0; i < 3*N; ++i )
    r[i]= tmp[i];

  stopS(&st);
  tprintf(&st, "\n");
  
  glutPostRedisplay();
}
