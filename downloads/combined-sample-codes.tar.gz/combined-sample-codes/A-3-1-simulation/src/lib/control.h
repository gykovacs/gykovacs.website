#ifndef _INIT_H_
#define _INIT_H_

/// a kamera pozicioja gombi koordinatarendszerben
int theta= 45, phi= 45, R= 1;
/// a navigacio soran hasznalt globalis valtozok
int buttonDown= 0, xOld, yOld, thetaOld, phiOld;
float scale= 100;

/**
 * a megjelenitest vegzo fuggveny
 */
void display(void);

/**
 * az egeresemenyeket kezelo fuggveny
 * @param button a lenyomott eger gomb azonositoja
 * @param state az allapot azonositoja
 * @param x vizszintes koordinata
 * @param y fuggoleges koordinata
 */
void mouse(int button, int state, int x, int y);

/**
 * az egermozgast kezelo fuggveny
 * @param x az egermutato uj vizszintes koordinataja
 * @param y az egermutato uj fuggololeges koordinataja
 */
void motion(int x, int y);

/**
 * az ablak atmeretezeset kezelo fuggveny
 * @param width az ablak uj szelessege
 * @param height az ablak uj magassaga
 */
void reshape(int width, int height);

/**
 * a grafikus kornyezetet inicializalo fuggveny
 * @param argc a parancssori argumentumok szama
 * @param argv a parancssori argumentumok tombje
 */
void glInit(int argc,char *argv[]);

#endif