#ifndef _STOPPER_H_
#define _STOPPER_H_

#include <time.h>

/** OpenMP alapu stopper tipus*/
typedef struct stopper
{
  double begin;	/// stopper futasanak kezdete
  double end; 	/// stopper futasanak vege
} stopper;

/** stoppperOMP inditasa
 * @param st az inditando stopperOMP cime
 */ 
void startS(stopper* st);

/** stopperOMP megallitasa
 * @param st a megallitando stopperOMP cime
 */ 
void stopS(stopper* st);

/** idotartamot cimkezve kiiro printf
 * @param st az idointervallumot tartalmazo stopper cime
 * @param fmt a printf-hez hasonlo ertelemben vett formatumsztring
 * @return a kiirt karakterek szama
 */ 
int tprintf(stopper* st, const char* fmt, ...);


#endif
