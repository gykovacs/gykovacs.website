#ifndef _SIMULATION_H_
#define _SIMULATION_H_

/// a reszecskek pozicioinak tombje
float* r;
/// a reszecskek sebessegeinek tombje
float* v;
/// a reszecskek tomegeinek tombje
float* m;
/// a kiszamolt poziciokat atmenetileg tarolo tomb
float* tmp;
/// a reszecskek szama
int N;
/// az idofelbontas
float dt;

/**
 * a reszecskeket inicializalo fuggveny
 */ 
void initObjects();

/**
 * a szimulacio egy lepeset megvalosito fuggveny
 */
void oneIteration();

#endif
