#include <control.h>
#include <GL/glut.h>
#include <simulation.h>
#include <math.h>

void display(void) 
{
  int i;

  glClear(GL_COLOR_BUFFER_BIT);
  glColor3f(255, 255, 255);
  glPushMatrix();
  glScalef(scale, scale, scale);
  gluLookAt( R*sin(phi*M_PI/180)*cos(theta*M_PI/180),
             R*sin(phi*M_PI/180)*sin(theta*M_PI/180),
             R*cos(phi*M_PI/180), 0, 0, 0, 0, 0, 1);
  
  glBegin(GL_LINES);
  glVertex3i(0,0,0);
  glVertex3i(1,0,0);
  glVertex3i(0,0,0);
  glVertex3i(0,1,0);
  glVertex3i(0,0,0);
  glVertex3i(0,0,1);
  glEnd();

  glColor3f(255, 255, 0);  
  
  glVertexPointer(3, GL_FLOAT, sizeof(GL_FLOAT)*3, r);
  glEnableClientState(GL_VERTEX_ARRAY);
  glDrawArrays(GL_POINTS, 0, N);
  glDisableClientState(GL_VERTEX_ARRAY);
  
  glPopMatrix();
  glutSwapBuffers();
}

void mouse(int button, int state, int x, int y)
{
  if( button == GLUT_LEFT_BUTTON && state == GLUT_DOWN ) 
  {
    buttonDown= 1;
    xOld= x;
    yOld= y;
    phiOld= phi;
    thetaOld= theta;
  }
  else if ( button == GLUT_LEFT_BUTTON && state != GLUT_DOWN )
    buttonDown= 0;
  else if ( button == 3 )
    scale+= 10;
  else if ( button == 4 )
    scale-= 10;
}
void motion(int x, int y) 
{
  if (buttonDown) 
  {
    phi= (phiOld - (y - yOld)) % 360;
    theta= (thetaOld - (x - xOld)) % 360;
    glutPostRedisplay();
  }
}

void reshape(int width, int height) 
{
  glViewport(0, 0, width, height);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  glOrtho(-300, 300, -300, 300, -300, 300);
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
}

void glInit(int argc,char *argv[]) 
{
  glutInit(&argc,argv);
  glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
  glutInitWindowSize(800, 800);
  glutInitWindowPosition(50, 50);
  glutCreateWindow("Gravitation simulation");
  glutDisplayFunc(display);
  glutReshapeFunc(reshape);
  glutMouseFunc(mouse);
  glutMotionFunc(motion);
  glutIdleFunc(oneIteration);
}

