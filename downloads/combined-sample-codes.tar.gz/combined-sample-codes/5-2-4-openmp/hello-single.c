#include <stdio.h>
#include <omp.h>

int main()
{
    int i;
    #pragma omp parallel num_threads(4), private(i)
    {
	i= 0;
	#pragma omp single copyprivate(i)
	{
	    printf("A munka kezdete elott adja meg az 'i' valtozo erteket (%d. szal)\n", omp_get_thread_num());
	    scanf("%d", &i);
	}
	i+= omp_get_thread_num();
	printf("%d ", i);
    }
    
    return 0;
}