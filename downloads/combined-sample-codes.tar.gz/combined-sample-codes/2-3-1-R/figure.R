library('ggplot2')
library('reshape')
library('Cairo')
library("grid")

plottitle <- "Teszt grafikon"
plotlabels <- c("szekvenciális implementáció", "párhuzamos implementáció")
xlabel <- expression(paste(alpha))
ylabel <- "Idő (s)"

data0 <- read.table('results-seq.dat')
data1 <- read.table('results-par.dat')
d <- data.frame(data0$V2, data0$V1, data1$V1)
colnames(d) <- c('alpha', 'runtime1', 'runtime2')
d <- melt(d, id='alpha', variable_name='series')

cairo_ps("test.eps", width=20, height=8)  
p<-ggplot(d, 
  aes_string(x=names(d)[1], y=names(d)[3], colour=names(d)[2]), 
  labeller=label_parsed) + 
  geom_point(size=4) + 
  geom_line(size=1.5) + 
  labs(title=plottitle) + 
  xlab(xlabel) + 
  ylab(ylabel) + 
  scale_colour_manual(values=c("black", "blue", "red", "green", "purple"), name="", labels=plotlabels, guide=guide_legend(keyheight=unit(2, "line"), keywidth=unit(5, "line"))) +
  theme_gray(24) +
  scale_x_continuous(breaks=round(seq(1.0, 10.0, by=0.5), 1)) +
  scale_y_continuous(breaks=sort(c(round(seq(0, max(d$value)+1, by=20), 1)))) +
  theme(legend.position="bottom")

print(p)
dev.off()
