#include <stdio.h>
#include <error.h>

void errorMessage(FILE* f, int code, char* label)
{
  switch(code)
  {
    case MPI_SUCCESS: fprintf(f, "%s - Successful return code.\n", label); break;
    case MPI_ERR_BUFFER: fprintf(f, "%s - Invalid buffer pointer.\n", label); break;
    case MPI_ERR_COUNT: fprintf(f, "%s - Invalid count argument.\n", label); break;
    case MPI_ERR_TYPE: fprintf(f, "%s - Invalid datatype argument.\n", label); break;
    case MPI_ERR_COMM: fprintf(f, "%s - Invalid communicator.\n", label); break;
    case MPI_ERR_RANK: fprintf(f, "%s - Invalid rank.\n", label); break;
    case MPI_ERR_REQUEST: fprintf(f, "%s - Invalid MPI_Request handle.\n", label); break;
    case MPI_ERR_ROOT: fprintf(f, "%s - Invalid root.\n", label); break;
    case MPI_ERR_GROUP: fprintf(f, "%s - Null group passed to function.\n", label); break;
    case MPI_ERR_TOPOLOGY: fprintf(f, "%s - Invalid topology.\n", label); break;
    case MPI_ERR_DIMS: fprintf(f, "%s - Illegal dimension argument.\n", label); break;
    case MPI_ERR_ARG: fprintf(f, "%s - Illegal argument.\n", label); break;
    case MPI_ERR_UNKNOWN: fprintf(f, "%s - Unknown error.\n", label); break;
    case MPI_ERR_TRUNCATE: fprintf(f, "%s - Message truncated on receive.\n", label); break;
    case MPI_ERR_OTHER: fprintf(f, "%s - Other error; use Error_string.\n", label); break;
    case MPI_ERR_INTERN: fprintf(f, "%s - Internal error code.\n", label); break;
    case MPI_ERR_IN_STATUS: fprintf(f, "%s - Look in status for error value.\n", label); break;
    case MPI_ERR_PENDING: fprintf(f, "%s - Pending request.\n", label); break;
    case MPI_ERR_ACCESS: fprintf(f, "%s - Permission denied.\n", label); break;
    case MPI_ERR_AMODE: fprintf(f, "%s - Unsupported amode passed to open.\n", label); break;
    case MPI_ERR_ASSERT: fprintf(f, "%s - Invalid assert.\n", label); break;
    case MPI_ERR_BAD_FILE: fprintf(f, "%s - Invalid file name (for example, path name too long).\n", label); break;
    case MPI_ERR_BASE: fprintf(f, "%s - Invalid base.\n", label); break;
    case MPI_ERR_CONVERSION: fprintf(f, "%s - An error occured in a user-supplied data-conversion function.\n", label); break;
    case MPI_ERR_DISP: fprintf(f, "%s - Invalid displacement.\n", label); break;
    case MPI_ERR_DUP_DATAREP: fprintf(f, "%s - Conversion functions could not be registered because a data representation identifier that was already defined was passed to MPI_REGISTER_DATAREP.\n", label); break;
    case MPI_ERR_FILE_EXISTS: fprintf(f, "%s - File exists.\n", label); break;
    case MPI_ERR_FILE_IN_USE: fprintf(f, "%s - File operation could not be completed, as the file is currently open by some process.\n", label); break;
    case MPI_ERR_FILE: fprintf(f, "%s - MPI_ERR_FILE.\n", label); break;
    case MPI_ERR_INFO_KEY: fprintf(f, "%s - Illegal info key.\n", label); break;
    case MPI_ERR_INFO_NOKEY: fprintf(f, "%s - No such key.\n", label); break;
    case MPI_ERR_INFO_VALUE: fprintf(f, "%s - Illegal info value.\n", label); break;
    case MPI_ERR_INFO: fprintf(f, "%s - Illegal info object.\n", label); break;
    case MPI_ERR_IO: fprintf(f, "%s - I/O error.\n", label); break;
    case MPI_ERR_KEYVAL: fprintf(f, "%s - Illegal key value.\n", label); break;
    case MPI_ERR_LOCKTYPE: fprintf(f, "%s - Illegal locktype.\n", label); break;
    case MPI_ERR_NAME: fprintf(f, "%s - Name not found.\n", label); break;
    case MPI_ERR_NO_MEM: fprintf(f, "%s - Memory exhausted.\n", label); break;
    case MPI_ERR_NOT_SAME: fprintf(f, "%s - MPI_ERR_NOT_SAME.\n", label); break;
    case MPI_ERR_NO_SPACE: fprintf(f, "%s - Not enough space.\n", label); break;
    case MPI_ERR_NO_SUCH_FILE: fprintf(f, "%s - File (or directory) does not exist.\n", label); break;
    case MPI_ERR_PORT: fprintf(f, "%s - Invalid port.\n", label); break;
    case MPI_ERR_QUOTA: fprintf(f, "%s - Quota exceeded.\n", label); break;
    case MPI_ERR_READ_ONLY: fprintf(f, "%s - Read-only file system.\n", label); break;
    case MPI_ERR_RMA_CONFLICT: fprintf(f, "%s - Conflicting accesses to window.\n", label); break;
    case MPI_ERR_RMA_SYNC: fprintf(f, "%s - Erroneous RMA synchronization.\n", label); break;
    case MPI_ERR_SERVICE: fprintf(f, "%s - Invalid publish/unpublish.\n", label); break;
    case MPI_ERR_SIZE: fprintf(f, "%s - Invalid size.\n", label); break;
    case MPI_ERR_SPAWN: fprintf(f, "%s - Error spawning.\n", label); break;
    case MPI_ERR_UNSUPPORTED_DATAREP: fprintf(f, "%s - Unsupported datarep passed to MPI_File_set_view.\n", label); break;
    case MPI_ERR_UNSUPPORTED_OPERATION: fprintf(f, "%s - Unsupported operation, such as seeking on a file that supports only sequential access.\n", label); break;
    case MPI_ERR_WIN: fprintf(f, "%s - Invalid window.\n", label); break;
    case MPI_ERR_LASTCODE: fprintf(f, "%s - Last error code.\n", label); break;
    case MPI_ERR_SYSRESOURCE: fprintf(f, "%s - Out of resources.\n", label); break;
  }
}