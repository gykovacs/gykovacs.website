#include <stdio.h>
#include <stdlib.h>
#include <omp.h>

int main(int argc, char** argv)
{
    int i;
    
    #pragma omp parallel num_threads(4)
    {
	#pragma omp for lastprivate(i), schedule(static,3)
	for ( i= 0; i < 20; ++i )
	{
	    printf("%d,%d ", omp_get_thread_num(), i); fflush(stdout);
	}
    }
    printf("\n%d\n", i);

    return 0;
}
