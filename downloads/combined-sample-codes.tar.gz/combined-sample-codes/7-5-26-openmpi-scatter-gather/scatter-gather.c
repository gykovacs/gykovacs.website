#include <stdio.h>
#include <mpi.h>
#include <float.h>
#include <error.h>
#include <math.h>

#define N 10

int main(int argc, char *argv[]) {
  int rank, size, err, i;
  float numbers[N];
  int npart;
  
  err= MPI_Init(&argc, &argv);
  ERROR(err, "MPI_Init");
 
  err= MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  ERROR(err, "MPI_Comm_rank");
  err= MPI_Comm_size(MPI_COMM_WORLD, &size);
  ERROR(err, "MPI_Comm_size");

  npart= N/size;
  
  if ( rank == 0 )
  {
    printf("Adjon meg %d szamot!\n", N);
    for ( i= 0; i < N; ++i )
      scanf("%f", numbers + i);
  }
  
  err= MPI_Scatter((void*)numbers, npart, MPI_FLOAT, (void*)numbers, npart, MPI_FLOAT, 0, MPI_COMM_WORLD);
  ERROR(err, "MPI_Scatter");
    
  for ( i= 0; i < npart; ++i )
    numbers[i]= sqrt(numbers[i]);
  
  err= MPI_Gather((void*)numbers, npart, MPI_FLOAT, (void*)numbers, npart, MPI_FLOAT, 0, MPI_COMM_WORLD);
  ERROR(err, "MPI_Gather");

  if ( rank == 0 )
    for ( i= size*npart; i < N; ++i )
      numbers[i]= sqrt(numbers[i]);
  
  if ( rank == 0 )
    for ( i= 0; i < N; ++i )
      printf("%f ", numbers[i]);
   

  err= MPI_Finalize();
  ERROR(err, "MPI_Finalize");
  
  return 0;
}
