#include <pthread.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

typedef struct parameter
{
    char* sztring;
    int id;
    pthread_t* threadID;
    pthread_mutex_t* hosszMutexMutato;
    int* maxHosszMutato;
} parameter;

void* szal(void* p)
{
    parameter* par= (parameter*)p;
    int hossz= strlen(par->sztring);
    
    pthread_mutex_lock(par->hosszMutexMutato);
    
    printf("Az %d szal zarolta a mutexet (hossz= %d, maxHossz=%d).\n", *(par->threadID), hossz, *(par->maxHosszMutato));
    if ( hossz > *(par->maxHosszMutato) )
	*(par->maxHosszMutato)= hossz;
    printf("A %d szal nyitja a mutexed (hossz= %d, maxHossz=%d).\n", *(par->threadID), hossz, *(par->maxHosszMutato));
    pthread_mutex_unlock(par->hosszMutexMutato);
    
    pthread_exit(NULL);
}

int main(int argc, char** argv)
{
    int i;
    pthread_t* ids= (pthread_t*)malloc(sizeof(pthread_t)*argc);
    parameter* par= (parameter*)malloc(sizeof(parameter)*argc);
    pthread_mutex_t hosszMutex;
    int maxHossz= -1;

    pthread_mutex_init(&hosszMutex, NULL);
    
    for ( i= 0; i < argc; ++i )
    {
	par[i].sztring= argv[i];
	par[i].id= i;
	par[i].threadID= ids + i;
	par[i].hosszMutexMutato= &hosszMutex;
	par[i].maxHosszMutato= &maxHossz;
	pthread_create(ids + i, NULL, szal, par + i);
    }
    for ( i= 0; i < argc; ++i )
	pthread_join(ids[i], NULL);

    pthread_mutex_destroy(&hosszMutex);

    printf("A leghosszabb parancssori argumentum hossza: %d\n", maxHossz);

    free(ids);
    free(par);
    
    return 0;
}
