#include <stdio.h>
#include <string.h>

int main(int argc, char** argv)
{
  char* p= argv[1];
  while ( p= strstr(p, argv[2]) )
  {
    printf("%s\n", p);
    fflush(stdout);
    
    p+= strlen(argv[2]);
  }

  return 0;
}
