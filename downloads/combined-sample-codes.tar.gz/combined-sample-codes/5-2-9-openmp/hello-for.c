#include <stdio.h>
#include <stdlib.h>
#include <omp.h>

#define N 10

int main(int argc, char** argv)
{
    int i;
    
    #pragma omp parallel num_threads(N)
    {
	#pragma omp for schedule(guided, 1), ordered
	for ( i= 0; i < N; ++i )
	{
		printf("%d ", i); fflush(stdout);
		#pragma omp ordered
			printf("o%d ", i); fflush(stdout);
	}
    }

    return 0;
}
